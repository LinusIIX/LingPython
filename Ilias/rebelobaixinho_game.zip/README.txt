PROJECT: learn 20 dothraki verbs
AUTHOR: filipe rebelo baixinho
OPERATING SYSTEM: Ubuntu 22.04.5 LTS partition in Windows 11 Home
PYTHON VERSION: Python 3.10.12
