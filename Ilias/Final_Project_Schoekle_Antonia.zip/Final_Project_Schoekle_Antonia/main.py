# Antonia Schökle Final Project
# 20 Adjectives Memory Game

# Import Pygame and Random modules
import pygame
import random
from assets import GameDataLink 

# Variable used to make sure the program can find the sound assets
subdir = "games/AdjectivesMemoryGame/"

# Initialize Pygame
pygame.init()

# Initialize sound module
pygame.mixer.init()

# Initialize timer
start_time = pygame.time.get_ticks()

# Load sound effects
# subdir variable is there to make sure it looks in the right place for the soundfiles
click_soundAMG = pygame.mixer.Sound(subdir + "clickAMG.wav")  # Sound for clicking a card
match_soundAMG = pygame.mixer.Sound(subdir + "sparkleAMG.wav")  # Sound for when a pair is found

# Load background music
pygame.mixer.music.load(subdir + "musicAMG.mp3")
pygame.mixer.music.play(-1)  # Play the music in a loop

# Adjust volume
click_soundAMG.set_volume(0.5)
match_soundAMG.set_volume(0.5)

# Set up game window
# Set up size for game window
WIDTH, HEIGHT = 900, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
#Set up caption for game window
pygame.display.set_caption("Adjectives Memory Game")

# Set up basic colors for background, back of cards, and text
WHITE = (255, 255, 255)
FACE_DOWN_COLOR = (200, 200, 200)
TEXT_COLOR = (0, 0, 0)

# Set up tuple with distinct colors to help remember which words belong together
COLORS = [
    (47, 79, 79), (46, 139, 87), (139, 0, 0), (128, 128, 0),
    (50, 50, 130), (255, 69, 0), (255, 165, 0), (255, 255, 0),
    (124, 252, 0), (186, 85, 211), (0, 255, 255), (0, 0, 255),
    (240, 128, 128), (255, 0, 255), (30, 144, 255), (221, 160, 221),
    (255, 20, 147), (152, 251, 152), (135, 206, 250), (255, 255, 224)
]

# Set up dictionary with 20 word pairs
WORDS = {
    "virzeth": "red", "thelis": "blue", "naqis": "small", "zhokwa": "big",
    "haje": "right", "sindarine": "left", "fish": "cold", "afazh": "hot",
    "haf": "quiet", "lavakh": "loud", "erin": "good", "mel": "evil",
    "kazga": "black", "zasqa": "white", "dik": "fast", "vroz": "slow",
    "ohazh": "heavy", "dei": "light", "driv": "dead", "thir": "alive"
}

# Create card pairs with assigned colors
all_cards = []
color_map = {}
color_index = 0

# Assign a unique color to each card pair
for dothraki, english in WORDS.items():
    pair_color = COLORS[color_index % len(COLORS)]  
    color_map[dothraki] = pair_color
    color_map[english] = pair_color
    all_cards.append((dothraki, pair_color, "dothraki"))
    all_cards.append((english, pair_color, "english"))
    color_index += 1

# Shuffle cards randomly
random.shuffle(all_cards)  

# Set up visual properties of cards
# Size
card_size = 90
# Distance
padding = 12
# Arranged in columns of 8 and fill in rows
cols = 8
rows = len(all_cards) // cols  

# Place grid
start_x = 48
start_y = 41


# Tracking game state
flipped_cards = []
matched_cards = []
# Set up attempt counter and score tracker
attempts = 0
score = 500
# Set up streak tracker
streak = 0 

# Counter for matched pairs that have been found
card_matches = 0

# Set up text font
font = pygame.font.Font(None, 28)
win_font = pygame.font.Font(None, 48)
ui_font = pygame.font.Font(None, 32)

# Define a function that writes the words on the cards
def draw_text_centered(text, x, y, font, color=TEXT_COLOR):
    rendered_text = font.render(text, True, color)
    text_rect = rendered_text.get_rect(center=(x, y))
    screen.blit(rendered_text, text_rect.topleft)

# Keep the program running until the player uncovers all cards
running = True
win = False  

while running:
    # Begin game, fill in game background
    screen.fill(WHITE)

    # Event handling
    for event in pygame.event.get():
        # Lets the player quit the game
        if event.type == pygame.QUIT:
            running = False
        # Debug feature: Press "D" to instantly win
        # elif event.type == pygame.KEYDOWN and event.key == pygame.K_d:
           # matched_cards = list(range(len(all_cards)))  # Mark all cards as matched
           # score = 500  # Set a test score 
           # win = True  # Trigger win screen

        # Check for mouse click
        elif event.type == pygame.MOUSEBUTTONDOWN and not win:
            # Lets the player flip two cards at a time
            if len(flipped_cards) < 2:
                # Find out where the screen was clicked
                mouse_x, mouse_y = event.pos

                # Loop through cards to find out which card was clicked
                for i, (word, color, lang) in enumerate(all_cards):
                    # Calculate the cards' positions based on arrangement, site and spacing and create hitboxes
                    x = start_x + (i % cols) * (card_size + padding)
                    y = start_y + (i // cols) * (card_size + padding)
                    card_rect = pygame.Rect(x, y, card_size, card_size)
                    
                    # Check if the click was within the hitbox of a card
                    # Making sure the card was not already flipped
                    if card_rect.collidepoint(mouse_x, mouse_y) and i not in flipped_cards and i not in matched_cards:
                        # Play click sound here
                        click_soundAMG.play()
                        # Reveal the card
                        flipped_cards.append(i)
                
    # Display cards
    # Go over all cards
    for i, (word, color, lang) in enumerate(all_cards):
        # Calculate the cards' positions again
        x = start_x + (i % cols) * (card_size + padding)
        y = start_y + (i // cols) * (card_size + padding)
        
        # Show card as revealed if it's been matched or is currently being flipped
        if i in flipped_cards or i in matched_cards:
            # Color card in its corresponding color
            pygame.draw.rect(screen, color, (x, y, card_size, card_size))
            # Write word on card
            draw_text_centered(word, x + card_size // 2, y + card_size // 2, font)
        # If not matched or revealed, show card as face-down
        else:
            pygame.draw.rect(screen, FACE_DOWN_COLOR, (x, y, card_size, card_size)) 

    # Check for match after every two cards that are flipped
    if len(flipped_cards) == 2:
        # Update screen so the player sees the second flip
        pygame.display.flip()
        # Pause for one second to let player memorize their cards
        pygame.time.delay(1000)  

        # Get word and color from the flipped cards
        idx1, idx2 = flipped_cards
        word1, color1, _ = all_cards[idx1]
        word2, color2, _ = all_cards[idx2]
        
        # Check if the colors are the same
        #If they match, the cards belong together
        if color1 == color2:
            # Play match sound here
            match_soundAMG.play()
            # Add them to flipped cards to make sure they stay flipped
            matched_cards.extend(flipped_cards)
            # Increase streak
            streak += 1
            # Count found pairs
            card_matches += 1

            # Determine bonus points based on streak lenght
            if streak == 2:
                bonus = 5
            elif streak == 3:
                bonus = 10
            elif streak >= 4:
                bonus = 15
            else:
                bonus = 0

            # Reward points for correct matches + streak bonus
            score += 10 + bonus
            
            # Reduce points for incorrect guesses and reset streak
        else:
            streak = 0
            score -= 3
            
        # Increase attempt counter
        attempts += 1
        # Reset flipped cards after each attempt
        flipped_cards.clear()  

    # Check win condition
    if len(matched_cards) == len(all_cards):
        win = True
         # Get final time
        total_time = (pygame.time.get_ticks() - start_time) // 1000

        # Stop background music
        pygame.mixer.music.stop()

        # Load different win music depending on score
        if score >= 600:
            pygame.mixer.music.load(subdir + "winAMG.mp3") 
        else:
            pygame.mixer.music.load(subdir + "loseAMG.mp3")

        # Show the final time
        draw_text_centered(f"Final Score: {score}", 450, 620, win_font)
        draw_text_centered(f"Time Taken: {total_time}s", 450, 660, win_font)

        pygame.mixer.music.play(0)  # Play the win music once

    # Display score and attempts
    draw_text_centered(f"Score: {score}", 750, 570, ui_font)
    draw_text_centered(f"Attempts: {attempts}", 750, 610, ui_font)

    # Calculate elapsed time in seconds
    elapsed_time = (pygame.time.get_ticks() - start_time) // 1000  

    # Display the timer on screen
    draw_text_centered(f"Time: {elapsed_time}s", 750, 650, ui_font) 


    # Display win screen upon finding all pairs
    if win:
        if score >= 600:
            draw_text_centered("You Win!", 450, 580, win_font)
            draw_text_centered(f"Final Score: {score}", 450, 620, win_font)
        else:
            draw_text_centered("Try to get at least 600 points!", 450, 580, win_font)
            draw_text_centered(f"Final Score: {score}", 450, 620, win_font)

        # Define button properties
        button_width = 160
        button_height = 40
        button_x = 50
        play_button_y = 570
        quit_button_y = 610

        # Draw buttons
        pygame.draw.rect(screen, (0, 200, 0), (button_x, play_button_y, button_width, button_height))  # Green Play Button
        pygame.draw.rect(screen, (200, 0, 0), (button_x, quit_button_y + 10, button_width, button_height))  # Red Quit Button
        draw_text_centered("Play Again", button_x + button_width // 2, play_button_y + button_height // 2, ui_font)
        draw_text_centered("Quit", button_x + button_width // 2, quit_button_y + 10 + button_height // 2, ui_font)

        pygame.display.flip()  # Refresh screen to show buttons

        # Wait for button click
        waiting = True
        while waiting:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    # If the player wants to exit the game, set running to false, program ends automatically
                    running = False
                    waiting = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_x, mouse_y = event.pos
                    # Check if "Play Again" was clicked
                    if button_x <= mouse_x <= button_x + button_width and play_button_y <= mouse_y <= play_button_y + button_height:
                        # Restart game
                        waiting = False
                        flipped_cards = []
                        matched_cards = []
                        attempts = 0
                        score = 500
                        random.shuffle(all_cards)
                        win = False
                    # Check if "Quit" was clicked
                    elif button_x <= mouse_x <= button_x + button_width and quit_button_y <= mouse_y <= quit_button_y + button_height:
                        # If "Quit" is clicked alse set running to false
                        running = False
                        waiting = False

    # Refresh the screen
    pygame.display.flip()

# Implement Game Data Link
gameData = GameDataLink.get_data() 
gameData["neededPoints"] = 20
gameData["text"] = "A game about teaching Dothraki adjectives"
gameData["rewardText"] = "Congratulations! You now know 20 Dothraki adjectives :)"

# The 'Points' used here are different from the 'Score' used in-game.
# The Points I send back to the main program are based off the ratio of matched pairs to attemps
# I decided to do this because my score starts at 500 and it would be easy to get a high score for basically doing nothing or a negative score for doing very poorly
# So the 'Points' are what is actually important and what gets sent back to the other program
# The 'Score! is just an extra gimmick/challenge

earned = card_matches
if ( (earned > 0) and (attempts >= 10) ):
   earned += int((10 * earned) / attempts)
gameData["earnedPoints"] += earned 
GameDataLink.send_data(gameData)

    
# Leave the game
pygame.quit()

