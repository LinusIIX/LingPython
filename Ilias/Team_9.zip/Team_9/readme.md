Team 9:
Jiamei Chen : 01/1478732
Yeganeh Mohammad Salehi : 01/1456323
Joselyn Maldonado : 01/1478729
Beatriz Marques Gomes da Motta : 01/1476499	

References 
"Pygame Level Design Tutorial" by Tech With Tim 
https://www.youtube.com/watch?v=Q-__8Xw9KTM

Lists 
https://docs.python.org/3/tutorial/datastructures.html#more-on-lists

-Python Programming for the Absolute Beginner - 3rd Edition
Author: Michael Dawson
Publisher: Course Technology

"Pygame Main Loop Tutorial" by Tech With Tim
https://www.youtube.com/watch?v=FfWpgLFMI7w

Pygame Time 
https://www.pygame.org/docs/ref/time.html

Wormy Code 
https://inventwithpython.com/pygame/chapter6.html

Iterate over a list in Python
https://www.geeksforgeeks.org/iterate-over-a-list-in-python/

-The Dothraki Language Dictionary - Version 3.11
Website: www.dothraki.org

Python - Global Variables 
https://www.w3schools.com/python/python_variables_global.asp

Pygame Official Website
Documentation: https://www.pygame.org/docs/
Tutorial Section: https://www.pygame.org/wiki/tutorials
Download and Installation Guide: https://www.pygame.org/download.shtml

Team Members Contribution:
Created the Dothraki level system for language learning (NP word order) and coded all the levels
Assigned to: Beatriz Marques Gomes da Motta
Created the game over screen if the player loses and the winning screen
Assigned to: Jiamei Chen
End the game if the player goes out of bounds or collects the wrong word order
Assigned to: Yeganeh Mohammad Salehi
Create the apples with the appropriate words on them
Assigned to: Joselyn Maldonado

Wormy: The Dothraki Language Learning Game
This game is a way to learn the Noun Phrase (NP) order in the Dothraki language! Inspired by the classic snake game, this version puts a linguistic twist on the challenge. you should collect words in the correct order to form proper Dothraki noun phrases.

How to Play:
-Control the Wormy using the arrow keys
-Each level presents a different Dothraki NP rule, like Noun + Adjective or Noun + Conjunction + Noun.
-Apples on the screen contain words, you must collect them in the correct order according to the level’s rule.
-If you pick up a word in the wrong order, it’s game over!
-Avoid crashing into the walls while navigating through the level.

The levels:
NP = N + Adj (e.g., "eyelki chosh")
NP = N + Conj + N (e.g., "eshin ma yette")
NP = N + Adj (e.g., "zhavvorsaan hoshor")

Operating System and Python Version
    MacOS
    Python 3 Sonoma 14.2