import pygame
import random
import sys
from pygame.locals import *
from assets import GameDataLink  #Importing GameDataLink

#PYGAME REFERENCES: Pygame Official Website
#Documentation: https://www.pygame.org/docs/;
#Tutorial Section: https://www.pygame.org/wiki/tutorials
#Download and Installation Guide: https://www.pygame.org/download.shtml

#REFERENCES THROUGHOUT ALL THE CODE:
# - Wormy Code https://inventwithpython.com/pygame/chapter6.html
# - Python Programming for the Absolute Beginner - 3rd Edition, Author: Michael Dawson, Publisher: Course Technology

#Setting up our game window size and speed
FPS = 10  #How fast the game runs
WINDOWWIDTH = 1280  #Width of game screen
WINDOWHEIGHT = 800  #Height of game screen
CELLSIZE = 20  #size of each grid square

#Making sure our window can be divided into perfect grid squares
assert WINDOWWIDTH % CELLSIZE == 0, "Window width must fit grid"
assert WINDOWHEIGHT % CELLSIZE == 0, "Window height must fit grid"

#Calculating how many grid squares we have
CELLWIDTH = WINDOWWIDTH // CELLSIZE
CELLHEIGHT = WINDOWHEIGHT // CELLSIZE

#Colors we'll use in our game
WHITE = (255, 255, 255)  #white color
BLACK = (0, 0, 0)  #background color
MAGENTA = (255, 0, 255)  #color for words/apples
CYAN = (0, 255, 255)  #bright blue
YELLOW = (255, 255, 0)  #snake color
DARKGRAY = (40, 40, 40)  #grid line color
BGCOLOR = BLACK  #background color

#Snake movement directions
UP = 'up'  #Moving up
DOWN = 'down'  #Moving down
LEFT = 'left'  #Moving left
RIGHT = 'right'  #Moving right
HEAD = 0  #First part of snake

#Our language learning levels
#each level has a different grammar rule and words
#REFERENCE: -The Dothraki Language Dictionary - Version 3.11, Website: www.dothraki.org
#REFERENCE: "Pygame Level Design Tutorial" by Tech With Tim, https://www.youtube.com/watch?v=Q-__8Xw9KTM

LEVELS = [
    {"rule": "NP = N + Adj", "words": ["eyelki", "chosh"]},  # Noun + Adjective
    {"rule": "NP = N + Conj + N", "words": ["eshin", "ma", "yette"]},  # Noun + Conjunction + Noun
    {"rule": "NP = N + Adj", "words": ["zhavvorsaan", "hoshor"]}  # Noun + Adjective
]

LEVELS = [
    {"rule": "NP = N + Adj", "words": ["eyelki", "chosh"]},  #Noun + Adjective
    {"rule": "NP = N + Conj + N", "words": ["eshin", "ma", "yette"]},  #Noun + Conjunction + Noun
    {"rule": "NP = N + Adj", "words": ["zhavvorsaan", "hoshor"]}  #Noun + Adjective
]

#game over reasons
OUT_OF_BOUNDS = 0
WRONG_WORD_ORDER = 1


def main():
    global FPSCLOCK, DISPLAYSURF, BASICFONT, SMALLFONT  #We used a global variable for game settings and elements we want to show;
    #REFERENCE: Python - Global Variables https://www.w3schools.com/python/python_variables_global.asp
    pygame.init()  #initializing pygame again
    FPSCLOCK = pygame.time.Clock()  #this controls the game’s speed (frames per second) REFERENCE: Pygame Time https://www.pygame.org/docs/ref/time.html

    DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))  #creating the game window

    #Using system fonts
    BASICFONT = pygame.font.SysFont(None, 36)
    SMALLFONT = pygame.font.SysFont(None, 24)

    pygame.display.set_caption('Wormy: Dothraki Game')  #Title of the game

    showStartScreen()  #Showing the start screen

    #Get initial game data
    gameData = GameDataLink.get_data()
    gameData["earnedPoints"] = 0
    gameData["neededPoints"] = 0
    gameData["text"] = "In this game, the player has to collect the apples in the correct NP word order."
    gameData["rewardText"] = "Congratulations, you have learned the NP word order!"

    for level in LEVELS:  #looping through all levels; REFERENCE: Iterate over a list in Python
        # https://www.geeksforgeeks.org/iterate-over-a-list-in-python/

        result = runGame(level, gameData)  #running current level with game data
        if result is not True:  #displaying game over if player loses
            showGameOverScreen(result)
            GameDataLink.send_data(gameData)  #sending game data after game over
            return  #to exit the game after game over

    #if the game is finished, send the final game data
    gameData["rewardText"] = "Congratulations, you have learned the NP word order!"
    GameDataLink.send_data(gameData)
    showWinScreen()  #Showing the win screen


def runGame(level, gameData):
    #REFERENCE: "Pygame Main Loop Tutorial" by Tech With Tim, https://www.youtube.com/watch?v=FfWpgLFMI7w
    wormCoords = [{'x': CELLWIDTH // 2, 'y': CELLHEIGHT // 2}]  #the starting position of the snake
    direction = RIGHT
    word_queue = list(level["words"])  #the words must be collected in this order; REFERENCE: #Python Lists
#https://docs.python.org/3/tutorial/datastructures.html#more-on-lists
    apple_words = random.sample(word_queue, len(word_queue))
    apples = [getRandomLocation() for _ in apple_words]  #random positions for each word the snake needs to get

    while True:
        for event in pygame.event.get():
            if event.type == QUIT:  #quits if window is closed
                terminate()
            elif event.type == KEYDOWN:  #to handle key presses
                if (event.key == K_LEFT or event.key == K_a) and direction != RIGHT:
                    direction = LEFT
                elif (event.key == K_RIGHT or event.key == K_d) and direction != LEFT:
                    direction = RIGHT
                elif (event.key == K_UP or event.key == K_w) and direction != DOWN:
                    direction = UP
                elif (event.key == K_DOWN or event.key == K_s) and direction != UP:
                    direction = DOWN
                elif event.key == K_ESCAPE:  #quits if “escape” is pressed
                    terminate()

        #Check collision with walls
        if wormCoords[HEAD]['x'] < 0 or wormCoords[HEAD]['x'] >= CELLWIDTH or \
                wormCoords[HEAD]['y'] < 0 or wormCoords[HEAD]['y'] >= CELLHEIGHT:
            return OUT_OF_BOUNDS  #out of bounds game over

        # Check collision with self
        for segment in wormCoords[1:]:
            if segment == wormCoords[HEAD]:
                return OUT_OF_BOUNDS  #hitting self game over

        # Check apple collection
        for i, apple in enumerate(apples):
            if wormCoords[HEAD]['x'] == apple['x'] and wormCoords[HEAD]['y'] == apple['y']:
                if apple_words[i] == word_queue[0]:
                    word_queue.pop(0)  #correct word collected
                    del apples[i]
                    del apple_words[i]
                    break
                else:
                    return WRONG_WORD_ORDER  #incorrect word order -> game over

        if not word_queue:
            return True  #Level completed

        #Moving the worm
        newHead = moveWorm(direction, wormCoords)
        wormCoords.insert(0, newHead)
        del wormCoords[-1]

        #To draw everything
        DISPLAYSURF.fill(BGCOLOR)
        drawGrid()
        drawWorm(wormCoords)
        drawApples(apples, apple_words)
        drawText(level['rule'], (WINDOWWIDTH // 2 - 100, 10), WHITE)
        pygame.display.update()
        FPSCLOCK.tick(FPS)

    return False


def moveWorm(direction, wormCoords):  #this moves the worm in the given direction
    if direction == UP:
        return {'x': wormCoords[HEAD]['x'], 'y': wormCoords[HEAD]['y'] - 1}
    elif direction == DOWN:
        return {'x': wormCoords[HEAD]['x'], 'y': wormCoords[HEAD]['y'] + 1}
    elif direction == LEFT:
        return {'x': wormCoords[HEAD]['x'] - 1, 'y': wormCoords[HEAD]['y']}
    elif direction == RIGHT:
        return {'x': wormCoords[HEAD]['x'] + 1, 'y': wormCoords[HEAD]['y']}


def getRandomLocation():  #this will return a random position within the grid
    return {'x': random.randint(0, CELLWIDTH - 1), 'y': random.randint(0, CELLHEIGHT - 1)}


def drawGrid():  #drawing grid lines on the screen
    for x in range(0, WINDOWWIDTH, CELLSIZE):
        pygame.draw.line(DISPLAYSURF, DARKGRAY, (x, 0), (x, WINDOWHEIGHT))
    for y in range(0, WINDOWHEIGHT, CELLSIZE):
        pygame.draw.line(DISPLAYSURF, DARKGRAY, (0, y), (WINDOWWIDTH, y))


def drawWorm(wormCoords):  #to draw the worm
    for coord in wormCoords:
        x = coord['x'] * CELLSIZE
        y = coord['y'] * CELLSIZE
        pygame.draw.rect(DISPLAYSURF, YELLOW, (x, y, CELLSIZE, CELLSIZE))


def drawApples(apples, words):  #to draw the apples with the words on them
    for i, apple in enumerate(apples):
        x = apple['x'] * CELLSIZE
        y = apple['y'] * CELLSIZE
        pygame.draw.rect(DISPLAYSURF, MAGENTA, (x, y, CELLSIZE, CELLSIZE))
        drawText(words[i], (x + 5, y + 5), WHITE)


def drawText(text, position, color, font=None):  #draws the text
    if font is None:
        font = BASICFONT
    textSurf = font.render(text, True, color)
    DISPLAYSURF.blit(textSurf, position)


def showStartScreen():  #shows the start screen
    DISPLAYSURF.fill(BGCOLOR)
    drawText("Wormy: Dothraki Game", (WINDOWWIDTH // 2 - 150, WINDOWHEIGHT // 2 - 150), CYAN, BASICFONT)
    instructions = [
        "Please Choose the Right NP Order!",
        "",
        "Game Rules:",
        "- Collect words in the correct Noun Phrase (NP) order",
        "- Move with Arrow Keys or WASD",
        "- Collect words following the level's NP rule",
        "- Incorrect order = Game Over!",
        "",
        "Press any key to start"
    ]
    #drawing the instructions
    for i, line in enumerate(instructions):
        color = WHITE
        drawText(line, (WINDOWWIDTH // 2 - 250, WINDOWHEIGHT // 2 - 100 + i * 30), color, SMALLFONT)#displays each instruction line

    pygame.display.update()
    pygame.time.wait(1000) #a small delay before starting
    checkForKeyPress()#waits for player input


def showGameOverScreen(reason):
    DISPLAYSURF.fill(BGCOLOR)

    if reason == OUT_OF_BOUNDS: #messages displayed if the player goes out of bounds
        drawText("Game Over!", (WINDOWWIDTH // 2 - 100, WINDOWHEIGHT // 2 - 50), MAGENTA)
        drawText("You hit a wall!", (WINDOWWIDTH // 2 - 100, WINDOWHEIGHT // 2), WHITE)
    elif reason == WRONG_WORD_ORDER: #messages displayed if the player chooses the wrong word order
        drawText("Game Over!", (WINDOWWIDTH // 2 - 100, WINDOWHEIGHT // 2 - 50), MAGENTA)
        drawText("Wrong word order!", (WINDOWWIDTH // 2 - 100, WINDOWHEIGHT // 2), WHITE)

    drawText("Press any key to exit", (WINDOWWIDTH // 2 - 120, WINDOWHEIGHT // 2 + 50), WHITE)#offers
    #the player to exit the game
    pygame.display.update()
    checkForKeyPress() #waits for player input before closing the game
    terminate() #closes the game


def showWinScreen(): #congratulations and main message
    DISPLAYSURF.fill(BGCOLOR)
    drawText("Congratulations!", (WINDOWWIDTH // 2 - 120, WINDOWHEIGHT // 2 - 100), CYAN)
    drawText("You've Mastered Noun Phrase (NP) Rules!", (WINDOWWIDTH // 2 - 250, WINDOWHEIGHT // 2 - 50), WHITE)
    #list with dothraki np rule explanation
    explanation = [
        "NP (Noun Phrase) Rules:",
        "1. NP = N + Adj: Noun + Adjective",
        "   Example: 'eyelki chosh (fresh spring)' - 'eyelki' is the noun, 'chosh' is the adjective",
        "2. NP = N + Conj + N: Noun + Conjunction + Noun",
        "   Example: 'eshin ma yette (fish and frogs)' - Nouns connected by a conjunction",
        "",
        "In language, NPs help describe and combine nouns!",
        "Press any key to exit"
    ]
    #to draw the explanation lines above
    for i, line in enumerate(explanation):
        drawText(line, (WINDOWWIDTH // 2 - 250, WINDOWHEIGHT // 2 + i * 30), WHITE, SMALLFONT)

    pygame.display.update()
    checkForKeyPress()
    terminate()


def checkForKeyPress():
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                terminate() #quits the game if the close button is clicked
            if event.type == KEYDOWN:
                return #proceeds when any key is pressed


def terminate():
    pygame.quit() #quits pygame
    sys.exit() #exits the program


if __name__ == '__main__':
    main() #this will start the game if the script is run directly
