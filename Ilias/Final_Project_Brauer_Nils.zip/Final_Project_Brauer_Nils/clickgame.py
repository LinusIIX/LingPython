
#version 2
#made by philipp hornung
import pygame
import random
from assets import GameDataLink  # Import the GameDataLink for data integration
from pygame.locals import *

# Initialize Pygame
pygame.init()

# Load game data from GameDataLink
gameData = GameDataLink.get_data()  # Retrieve the game data (points, needed points, etc.)
gameData["neededPoints"] = 10  # Set the goal for the game to 10 points
gameData["text"] = "Click on the targets to earn points!"  # Text to display in the game
print(gameData)  # Print the initial game data (for debugging purposes)

# Set up the display
WIDTH, HEIGHT = 600, 400  # Set the screen width and height
dp = pygame.display.set_mode((WIDTH, HEIGHT), pygame.HWSURFACE | pygame.DOUBLEBUF)  # Create the game window

# Set up font for rendering text
font = pygame.font.Font('freesansbold.ttf', 32)  # Font settings for displaying text

# Game settings
target_radius = 25  # Set the radius of the target (red circle)
target_color = (255, 0, 0)  # Color of the target (red)

# Game state flags
game_over = False  # Flag to check if the game is over
earned_points = gameData["earnedPoints"]  # Initialize earned points from game data

# Function to generate a random position for the target
def get_random_position():
    # Return a random position within the screen boundaries, ensuring the target is not off-screen
    return random.randint(target_radius, WIDTH - target_radius), random.randint(target_radius, HEIGHT - target_radius)

# Generate the first target position randomly
target_x, target_y = get_random_position()

# Main game loop
while True:
    dp.fill((200, 255, 255))  # Fill the screen with a light color

    # Handle all events (like quitting the game or mouse click)
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            # If the player closes the window, send the final game data and exit
            gameData["earnedPoints"] = earned_points
            if earned_points >= gameData["neededPoints"]:
                gameData["rewardText"] = "Well done! You clicked enough targets! Here are some hints: jin=this, jinak=this (when speaking of person) and jini (when speaking of an inanimate object). "
            GameDataLink.send_data(gameData)  # Send the updated game data
            exit()  # Exit the game

        if e.type == pygame.MOUSEBUTTONDOWN:
            # Check if the player clicked on the target
            mouse_x, mouse_y = e.pos
            # Calculate the distance from the mouse click to the target center
            distance = ((mouse_x - target_x) ** 2 + (mouse_y - target_y) ** 2) ** 0.5
            if distance <= target_radius:  # If the distance is within the target radius
                earned_points += 1  # Increase the player's score
                gameData["earnedPoints"] = earned_points  # Update the earned points in game data

                # Check if the player has earned enough points to win
                if earned_points >= gameData["neededPoints"]:
                    game_over = True  # Set game over flag to true
                    gameData["rewardText"] = "Well done! You clicked enough targets! Here are some hints: jin=this, jinak=this (when speaking of person) and jini (when speaking of an inanimate object)."  # Set the reward text
                    GameDataLink.send_data(gameData)  # Send the updated game data
                    exit()  # Exit the game
                
                # Generate a new random target position after the player clicks the target
                target_x, target_y = get_random_position()

    # Draw the target on the screen
    pygame.draw.circle(dp, target_color, (target_x, target_y), target_radius)

    # Display the earned points and the game instructions
    text = font.render(f"Earned Points: {earned_points}/{gameData['neededPoints']}", True, (0, 0, 0))
    dp.blit(text, (20, 20))  # Render and display the earned points
    text2 = font.render(gameData["text"], True, (0, 0, 0))
    dp.blit(text2, (20, 60))  # Render and display the game instructions

    # Update the display with the new frame
    pygame.display.flip()

    # Cap the frame rate at 60 frames per second
    pygame.time.Clock().tick(60)


