# Made by Nils Brauer

import pygame
import random
import os
from assets import GameDataLink  # Import the GameDataLink for data integration
from pygame.locals import *
# Initialize Pygame
pygame.init()

# Load game data from GameDataLink
gameData = GameDataLink.get_data()  # Retrieve the game data (points, needed points, etc.)
gameData["neededPoints"] = 10  # Set the goal for the game to 10 points
gameData["text"] = "Collect the stars to earn points!"  # Text to display in the game
print(gameData)  # Print the initial game data (for debugging purposes)


# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Starship Adventure")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

# Get the directory of the current script
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# Load and resize images
starship_img = pygame.transform.scale(pygame.image.load(os.path.join(SCRIPT_DIR, "starship.png")), (50, 50))  # Resize to 50x50
meteor_img = pygame.transform.scale(pygame.image.load(os.path.join(SCRIPT_DIR, "meteor.png")), (40, 40))      # Resize to 40x40
star_img = pygame.transform.scale(pygame.image.load(os.path.join(SCRIPT_DIR, "star.png")), (30, 30))          # Resize to 30x30

# Load sounds
pygame.mixer.music.load(os.path.join(SCRIPT_DIR, "background_music.mp3"))  # Background music (MP3)
collect_sound = pygame.mixer.Sound(os.path.join(SCRIPT_DIR, "collect_star.mp3"))  # Sound for collecting a star (MP3)
crash_sound = pygame.mixer.Sound(os.path.join(SCRIPT_DIR, "crash.mp3"))  # Sound for crashing into a meteor (MP3)


# Starship settings
starship_width, starship_height = 50, 50
starship_x = WIDTH // 2 - starship_width // 2
starship_y = HEIGHT - starship_height - 10
starship_speed = 5

# Meteor settings
meteor_width, meteor_height = 40, 40
meteor_speed = 3
meteors = []

# Star settings
star_width, star_height = 30, 30
stars = []
stars_collected = 0

# Lives
lives = 3

# Clock
clock = pygame.time.Clock()

earned_points = gameData["earnedPoints"]  # Initialize earned points from game data

# Font for messages
font = pygame.font.SysFont("Arial", 50)
small_font = pygame.font.SysFont("Arial", 30)

def draw_starship(x, y):
    screen.blit(starship_img, (x, y))

def draw_meteor(x, y):
    screen.blit(meteor_img, (x, y))

def draw_star(x, y):
    screen.blit(star_img, (x, y))

def display_message(text, color, y_offset=0):
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(center=(WIDTH // 2, HEIGHT // 2 + y_offset))
    screen.blit(text_surface, text_rect)

def display_start_screen():
    screen.fill(BLACK)
    display_message("STARSHIP ADVENTURE", GREEN, -50)
    display_message("Press SPACE to Start", WHITE, 50)
    pygame.display.update()

def display_failure_screen():
    screen.fill(BLACK)
    display_message("GAME OVER", RED, -50)
    display_message("Press SPACE to Restart", WHITE, 50)
    pygame.display.update()

def display_victory_screen():
    screen.fill(BLACK)
    display_message("VICTORY!", GREEN, -50)
    pygame.display.update()

def reset_game():
    global starship_x, starship_y, meteors, stars, stars_collected, lives
    starship_x = WIDTH // 2 - starship_width // 2
    starship_y = HEIGHT - starship_height - 10
    meteors = []
    stars = []
    stars_collected = 0
    lives = 3
    earned_points = 0



# Start screen
start_screen = True
while start_screen:
    display_start_screen()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                start_screen = False

# Play background music (loop indefinitely)
pygame.mixer.music.play(-1)

# Main game loop
running = True
while running:
    screen.fill(BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Move starship
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and starship_x > 0:
        starship_x -= starship_speed
    if keys[pygame.K_RIGHT] and starship_x < WIDTH - starship_width:
        starship_x += starship_speed

    # Spawn meteors
    if random.randint(1, 20) == 1:
        meteor_x = random.randint(0, WIDTH - meteor_width)
        meteor_y = -meteor_height
        meteors.append((meteor_x, meteor_y))

    # Move meteors
    for i, (meteor_x, meteor_y) in enumerate(meteors):
        meteor_y += meteor_speed
        meteors[i] = (meteor_x, meteor_y)
        if meteor_y > HEIGHT:
            meteors.pop(i)
            break

        # Check for collision with starship
        if (starship_x < meteor_x + meteor_width and
            starship_x + starship_width > meteor_x and
            starship_y < meteor_y + meteor_height and
            starship_y + starship_height > meteor_y):
            meteors.pop(i)
            lives -= 1
            crash_sound.play()  # Play crash sound
            if lives == 0:
                pygame.mixer.music.stop()  # Stop background music
                display_failure_screen()
                pygame.time.delay(1000)  # Short delay to show the failure screen
                waiting = True
                while waiting:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            quit()
                        if event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_SPACE:
                                reset_game()
                                pygame.mixer.music.play(-1)  # Restart background music
                                waiting = False
                break

    # Spawn stars
    if random.randint(1, 50) == 1 and len(stars) < 5:
        star_x = random.randint(0, WIDTH - star_width)
        star_y = -star_height
        stars.append((star_x, star_y))

    # Move stars
    for i, (star_x, star_y) in enumerate(stars):
        star_y += 2
        stars[i] = (star_x, star_y)
        if star_y > HEIGHT:
            stars.pop(i)
            break

        # Check for collection by starship
        if (starship_x < star_x + star_width and
            starship_x + starship_width > star_x and
            starship_y < star_y + star_height and
            starship_y + starship_height > star_y):
            stars.pop(i)
            stars_collected += 1
            collect_sound.play()  # Play collect sound
            earned_points += 1
            gameData["earnedPoints"] = earned_points
            GameDataLink.send_data(gameData)
            break

    # Draw everything
    draw_starship(starship_x, starship_y)
    for meteor in meteors:
        draw_meteor(*meteor)
    for star in stars:
        draw_star(*star)

    # Display stars collected and lives
    stars_text = small_font.render(f"Stars: {stars_collected}", True, WHITE)
    lives_text = small_font.render(f"Lives: {lives}", True, WHITE)
    screen.blit(stars_text, (10, 10))
    screen.blit(lives_text, (10, 50))

    # Check for victory
    if stars_collected >= gameData["neededPoints"]:
        pygame.mixer.music.stop()  # Stop background music
        display_victory_screen()
        pygame.time.delay(1000)  # Short delay to show the victory screen
        gameData["rewardText"] = "Well done! You are a capable pilot! Here are some hints: jin=this, jinak=this (when speaking of person) and jini (when speaking of an inanimate object)."
        GameDataLink.send_data(gameData)
        pygame.quit()
        quit()

    # Update display
    pygame.display.update()
    clock.tick(60)

pygame.quit()