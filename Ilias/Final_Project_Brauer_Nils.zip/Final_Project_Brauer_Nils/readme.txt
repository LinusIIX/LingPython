Hello and welchome to the world of the arcade machine.


In our scenario the user finds an old arcade machine and turns it on...
Our idea was to give the user a choice of games to get the information he wants.
First he chooses a game in the arcade machine wich he then has to complete the clicker game is a lot easier while the starhip game is a bit more complicated.
After completion of the game the user is required to close the arcade machine and then is presented with the information about the translation of the Dothraki word.
After closing the machine the user also can enter the machine and play again or play the other game but wont get any other information.

IMPORTANT: The user can not play one game to completion then without closing the arcade machine play the other game since that throws errors on the gamedatalink side!!!

With that being said, have fun playing the games and good luck.