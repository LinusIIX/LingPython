#Made by Nils Brauer with help from Philipp Hornung

import pygame
import os
import subprocess
from pygame.locals import *

# Initialize Pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Arcade Machine")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)  # Yellow color

# Get the directory of the current script
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# Load a retro 8-bit font (replace "retro_font.ttf" with your font file)
try:
    retro_font = pygame.font.Font(os.path.join(SCRIPT_DIR, "retro_font.ttf"), 50)
    small_retro_font = pygame.font.Font(os.path.join(SCRIPT_DIR, "retro_font.ttf"), 30)
    tiny_retro_font = pygame.font.Font(os.path.join(SCRIPT_DIR, "retro_font.ttf"), 10)
    normal_font = pygame.font.SysFont("Arial", 30)
except FileNotFoundError:
    #print("Retro font not found. Using default font.")
    retro_font = pygame.font.SysFont("Arial", 50)
    small_retro_font = pygame.font.SysFont("Arial", 30)


# Load background image
background_image = pygame.image.load(os.path.join(SCRIPT_DIR, "background.jpg"))
background_image = pygame.transform.scale(background_image, (WIDTH, HEIGHT))  # Resize to fit screen

# Game options
games = [
    {"name": "Click Game", "file": os.path.join(SCRIPT_DIR, "clickgame.py")},
    {"name": "Starship Game", "file": os.path.join(SCRIPT_DIR, "starshipgame.py")},
    {"name": "Exit", "file": None}  # Close button as a selectable option
]
selected_index = 0

# Hardcoded information text with newlines
info_text = (
    "Choose your game and collect all 10 Points!"
    "You can only play one game so choose carefully."
    "Use the arrow keys to navigate and ENTER to select."
    "Press ESC to exit at any time. After you won the game you can close the machine."
)

# Function to wrap text into multiple lines
def wrap_text(text, font, max_width):
    words = text.split(" ")
    lines = []
    current_line = ""

    for word in words:
        # Check if adding the word exceeds the max width
        test_line = current_line + " " + word if current_line else word
        test_width, _ = font.size(test_line)

        if test_width <= max_width:
            current_line = test_line
        else:
            # Start a new line
            lines.append(current_line)
            current_line = word

    # Add the last line
    if current_line:
        lines.append(current_line)

    return lines

# Function to draw the menu
def draw_menu():
    # Draw background image
    screen.blit(background_image, (0, 0))

    # Draw title
    title_text = retro_font.render("Select a Game", True, YELLOW)
    screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, 50))

    # Draw game options
    for i, game in enumerate(games):
        color = YELLOW if i == selected_index else WHITE
        game_text = small_retro_font.render(game["name"], True, color)
        screen.blit(game_text, (WIDTH // 2 - game_text.get_width() // 2, 200 + i * 50))

    # Draw hardcoded information text
    max_text_width = WIDTH - 40  # Leave some padding on the sides
    wrapped_lines = wrap_text(info_text, normal_font, max_text_width)

    # Draw each line of the wrapped text
    y_offset = HEIGHT - 200
    for line in wrapped_lines:
        info_surface = normal_font.render(line, True, YELLOW)
        screen.blit(info_surface, (WIDTH // 2 - info_surface.get_width() // 2, y_offset))
        y_offset += (normal_font.get_height() + 5)  # Add spacing between lines

    pygame.display.update()

# Main loop
running = True
while running:
    draw_menu()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                selected_index = (selected_index - 1) % len(games)
            elif event.key == pygame.K_DOWN:
                selected_index = (selected_index + 1) % len(games)
            elif event.key == pygame.K_RETURN:
                # Handle the selected option
                selected_game = games[selected_index]["file"]
                if selected_game is None:  # Exit option
                    running = False
                else:
                    try:
                        subprocess.run(["python", selected_game])
                    except Exception as e:
                        print(f"Error launching game: {e}")
            elif event.key == pygame.K_ESCAPE:
                running = False

# Quit Pygame
pygame.quit()