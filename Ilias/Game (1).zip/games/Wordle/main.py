# Project by Adrian Sopio and Odin Weber
# Implementation of Wordle with pygame (https://www.nytimes.com/games/wordle/index.html)
# Run on Windows 10 with Python 3.10.11

# Wordle logic done by Adrian Sopio
# Implementation in pygame and project structure by Odin Weber

import pygame
import random
import os
from assets import GameDataLink

pygame.init()

# Stuff for integration and sending data to main menu interface
# Main menu and interface for integrating all games into a single project provided on Ilias by team 14 (Linus Prange, Luca Pomm, Daniel Shaw, Nils Schiele)
gameData = GameDataLink.get_data()
gameData["neededPoints"] = 1
gameData["earnedPoints"] = 0
gameData["text"] = "Wordle: Find the correct 5-letter word."

# rewards text about word order and conjunction of Dothraki
reward_text =   ("Well done on completing Wordle! As a reward, you gain knowledge of the unknown language:"
                "\n1) The basic word order is Subject-Verb-Object."
                "\n2) 'ma' means 'and'."
                "\n3) Adjectives come after the word they are modifying."
                "\n4) Adverbs come before the adjective they are modifying."
                "\n5) Possession is expressed as X of Y instead of X's Y.\n\n")

gameData["rewardText"] = ""

# define space and font sizes
WIDTH, HEIGHT = 600, 700
ROWS, COLS = 6, 5
CELL_SIZE = 80
MARGIN = 10
FONT = pygame.font.Font(None, 60)
SMALL_FONT = pygame.font.Font(None, 30)

# define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 200, 0)
YELLOW = (200, 200, 0)
GRAY = (100, 100, 100)
BUTTON_COLOR = (0, 0, 255)
BUTTON_HOVER_COLOR = (0, 0, 200)
TEXT_COLOR = (255, 255, 255)

# Done By Adrian Sopio:
# Get the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))

# Build the paths to the files relative to the script
# Past Wordle answers, sorted lexicographically, taken from https://gist.github.com/cfreshman/a03ef2cba789d8cf00c08f767e0fad7b
answers_path = os.path.join(script_dir, "answers.txt") 
# Allowed Wordle guesses, sorted lexicographically, taken from https://gist.github.com/cfreshman/cdcdf777450c5b5301e439061d29694c
guesses_path = os.path.join(script_dir, "allowed_guesses.txt")

# Load possible solutions
with open(answers_path) as f:
    WORDS = [line.strip().lower() for line in f]

# Load allowed guesses
with open(guesses_path) as f:
    # The file does not contain the words from the ANSWERS file, even though they are allowed as well, so we have to join them
    ALLOWED_GUESSES = {line.strip().lower() for line in f}.union(set(WORDS))

# Function to restart the game after pressing button
def restart_game():
    global SOLUTION, guesses, current_guess, game_over, message
    SOLUTION = random.choice(WORDS)
    guesses = []
    current_guess = ""
    game_over = False
    message = ""

# Select a random word from list
SOLUTION = random.choice(WORDS)

# check if the guess is a valid word
def check_guess(guess):
    result = [0] * 5  # 0: wrong, 1: wrong place, 2: correct
    solution_chars = list(SOLUTION)
    
    # check correct positions
    for i in range(5):
        if guess[i] == SOLUTION[i]:
            result[i] = 2 # A correct letter at the correct spot is indicated by 2
            solution_chars[i] = None  # Remove matched letters
    
    # check misplaced letters
    for i in range(5):
        if result[i] == 0 and guess[i] in solution_chars:
            result[i] = 1 # Correct letter at wrong spot is indicated by 1
            solution_chars[solution_chars.index(guess[i])] = None
    
    return result # return result array with numbers

# Pygame setup, done by Odin Weber
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Wordle")

guesses = []
current_guess = ""
game_over = False
message = ""

# Button positions
exit_button = pygame.Rect(WIDTH - 120, 20, 100, 50)
restart_button = pygame.Rect(WIDTH - 310, 20, 180, 50)
instructions_button = pygame.Rect(20, 20, 260, 50)

# Instruction flag and text box position
show_instructions = False
instruction_box = pygame.Rect(50, 150, WIDTH - 100, HEIGHT - 250)

# Game grid vertical position
grid_y_start = 100  # Height from the top to start the grid (after buttons)

# Function for creating the buttons
def draw_button(rect, text):
    pygame.draw.rect(screen, BUTTON_COLOR, rect)
    text_surface = FONT.render(text, True, TEXT_COLOR)
    screen.blit(text_surface, (rect.x + (rect.width - text_surface.get_width()) // 2,
                               rect.y + (rect.height - text_surface.get_height()) // 2))

# Event handler for clicking buttons
def handle_buttons(mouse_pos):
    global game_over, message, show_instructions
    if exit_button.collidepoint(mouse_pos): # exit button
        GameDataLink.send_data(gameData) # send game data to main menu structure if quitting game
        pygame.quit()
        quit()
    elif restart_button.collidepoint(mouse_pos): # restart button
        restart_game()
    elif instructions_button.collidepoint(mouse_pos): # instruction button
        show_instructions = not show_instructions  # Toggle instruction display

# Instruction text
instruction_text = [
    "Wordle Instructions:",
    "1. Guess the 5-letter word.",
    "2. Use 'Enter' to submit your guess.",
    "3. Use 'Backspace' to delete letters.",
    "4. Green means correct letter and position.",
    "5. Yellow means correct letter, wrong position.",
    "6. Gray means wrong letter.",
    "7. You have 6 guesses."
]

running = True
while running:
    screen.fill(WHITE) # white background
    
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # quit game
            running = False
        elif event.type == pygame.KEYDOWN and not game_over: # input chars
            if event.key == pygame.K_RETURN and len(current_guess) == 5: # press enter to lock your guess in
                if current_guess in ALLOWED_GUESSES: # if guess is valid, add it to all guesses
                    guesses.append((current_guess, check_guess(current_guess)))
                    message = ""
                    if current_guess == SOLUTION: # if correct solution
                        game_over = True
                        message = "You Win!"
                        print(f"\n\n{reward_text}") # output reward text on console
                        gameData["earnedPoints"] += 1
                        gameData["rewardText"] = reward_text
                        GameDataLink.send_data(gameData) # Send game data to the main menu after completing game
                        
                    elif len(guesses) == 6: # if all 6 guesses  are used up, its over
                        game_over = True
                        message = f"Answer: {SOLUTION.upper()}"

                    current_guess = ""
                else:
                    message = "Invalid word!"
            elif event.key == pygame.K_BACKSPACE: # delete chars if pressed backspace
                current_guess = current_guess[:-1]
            elif len(current_guess) < 5 and event.unicode.isalpha(): # get the curent guess from the user input
                current_guess += event.unicode.lower()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  # on left mouse click
            handle_buttons(event.pos) # check for buttons when mouse click
    
    # Draw grid
    for r in range(ROWS):
        for c in range(COLS):
            x, y = c * (CELL_SIZE + MARGIN) + MARGIN, r * (CELL_SIZE + MARGIN) + grid_y_start + MARGIN
            color = WHITE
            letter = ""
            if r < len(guesses): # display the guesses
                letter = guesses[r][0][c].upper() # r is the number of the guess, c the corresponding number (0=incorrect, 1=wrong place, 2=correct)
                color = [GRAY, YELLOW, GREEN][guesses[r][1][c]] # display the right cell color
            elif r == len(guesses) and c < len(current_guess): # display the current input dynamically
                letter = current_guess[c].upper()
            pygame.draw.rect(screen, color, (x, y, CELL_SIZE, CELL_SIZE))
            pygame.draw.rect(screen, BLACK, (x, y, CELL_SIZE, CELL_SIZE), 3)
            if letter:
                text = FONT.render(letter, True, BLACK)
                screen.blit(text, (x + CELL_SIZE // 3, y + CELL_SIZE // 4))
    
    # Display message beneath grid
    text = FONT.render(message, True, BLACK)
    screen.blit(text, (WIDTH // 4, HEIGHT - 50))

    # Draw buttons
    draw_button(exit_button, "Exit")
    draw_button(restart_button, "Restart")
    draw_button(instructions_button, "Instructions")

    # Draw instruction text box if visible
    if show_instructions:
        pygame.draw.rect(screen, BLACK, instruction_box) # outer box
        pygame.draw.rect(screen, WHITE, instruction_box.inflate(-10, -10))  # inner box with padding
        
        # Display instruction text
        for i, line in enumerate(instruction_text):
            text_surface = SMALL_FONT.render(line, True, BLACK)
            screen.blit(text_surface, (instruction_box.x + 10, instruction_box.y + 10 + i * 30))
    
    pygame.display.flip()

pygame.quit()
