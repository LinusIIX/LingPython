Project by Adrian Sopio and Odin Weber
Implementation of Wordle with pygame (https://www.nytimes.com/games/wordle/index.html)
Run on Windows 10 with Python 3.10.11

Main menu and interface for integrating all games into a single project provided on Ilias by team 14 (Linus Prange, Luca Pomm, Daniel Shaw, Nils Schiele)
In the main menu navigate with WASD, press E to select game

Own code in games/Wordle/main.py
Wordle logic done by Adrian Sopio
Implementation in pygame by Odin Weber

Past Wordle answers, sorted lexicographically, taken from https://gist.github.com/cfreshman/a03ef2cba789d8cf00c08f767e0fad7b
Allowed Wordle guesses, sorted lexicographically, taken from https://gist.github.com/cfreshman/cdcdf777450c5b5301e439061d29694c

Run the code with "python main.py" in this directory
If it doesn't work, try changing 'python' to 'python3' in line 48 of assets/Engine.py