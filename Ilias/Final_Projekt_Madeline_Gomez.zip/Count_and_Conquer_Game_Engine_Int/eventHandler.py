# eventHandler.py
# author: Teresa Madeline

from collections.abc import Callable
import pygame, sys
from pygame.locals import *
import menu as m
import draw as d
import constant as c

def event_handler(i: int, n: int, text, prev_scene: Callable, next_scene: Callable, curr_scene: Callable):
    """
    Handles User Input for all Dialogue events
    :param i: Current line index.
    :param n: Number of characters to display from the current line.
    :param text: List of dialogue strings.
    :param prev_scene: function that describes one scene prior
    :param next_scene: function that describes one scene after
    :param curr_scene: function that describes current scene
    :return: updated i, n, next function to call, state of the game
    """
    event_info = handle_events(context='dialogue')

    if event_info['action'] == 'quit': # quit
        return i, n, sys.exit, "quit"
    elif event_info['action'] == 'pause': # pause
        return i, n, m.pause_menu(curr_scene), "pause"
    elif event_info['action'] == 'progress': # progress
        if n >= len(text[i]) - 1:
            if i < len(text) - 1:
                return i + 1, 0, None, None # next dialogue
            else:
                return i, n, next_scene, None # next scene
        else:
            return i, len(text[i]), None, None
    elif event_info['action'] == 'back': # back
        if i > 0:
            return i - 1, 0, None, "back" # prev dialogue
        else:
            return i, n, prev_scene, None # prev scene
    elif event_info['action'] == 'select': # select
        return i, n, None, "select"

    return i, n, None, None


def handle_events(context='dialogue', option_rects=None, input_active=False):
    """
    Handles user input events such as key presses, mouse clicks, and movement.
    :param context: (str) The current game context ('dialogue', 'combat', 'shop', etc.).
    :param option_rects: (list) List of option button rectangles (for selection in menus).
    :param input_active: (bool) Whether text input is active (for combat text input).
    :return: (dict) A dictionary containing event details including action type, key pressed, direction, and text input.
    """

    # Initialize a dictionary to store event details
    action_info = {
        'action': None,  # General action (e.g., 'quit', 'pause', 'select')
        'direction': None,  # Navigation direction ('up', 'down')
        'option': None,  # Selected option index (for menus)
        'text': '',  # Text input (if applicable)
        'event': None,  # Pygame event type
        'key': None,  # Key pressed (if applicable)
        'unicode': ''  # Unicode character for text input
    }

    # Loop through all Pygame events
    for event in pygame.event.get():
        action_info['event'] = event.type  # Store the event type
        action_info['key'] = event.key if event.type == KEYDOWN else None
        action_info['unicode'] = event.unicode if event.type == KEYDOWN else ''

        # Handle quit event (window close)
        if event.type == QUIT:
            action_info['action'] = 'quit'
            return action_info

        # Handle keyboard input
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                # Escape key behavior varies by context
                if input_active and context == 'combat':
                    action_info['action'] = 'back'  # Exit combat text input
                    return action_info
                action_info['action'] = 'pause'  # Pause game otherwise
                return action_info

            # Handle text input in combat mode
            if input_active and context == 'combat':
                if event.key == K_RETURN:
                    action_info['action'] = 'submit_text'  # Submit entered text
                    return action_info
                if event.key == K_ESCAPE:
                    action_info['action'] = 'back'  # Cancel text input
                    return action_info
                elif event.key == K_BACKSPACE:
                    action_info['action'] = 'backspace'  # Delete a character
                    return action_info
                else:
                    action_info['action'] = 'text_input'  # General text input event
                    return action_info

            # Handle navigation in menus (combat/shop/dictionary)
            if context in ('combat', 'shop', 'dict'):
                if event.key == K_UP:
                    action_info.update({'action': 'navigate', 'direction': 'up'})
                    return action_info
                elif event.key == K_DOWN:
                    action_info.update({'action': 'navigate', 'direction': 'down'})
                    return action_info
                elif event.key in (K_SPACE, K_RETURN):
                    action_info.update({'action': 'select', 'option': c.selected_option})
                    return action_info

            # Handle dialogue progression
            elif context == 'dialogue':
                if event.key in (K_SPACE, K_RETURN):
                    action_info['action'] = 'progress'  # Move to the next dialogue
                    return action_info
                elif event.key == K_BACKSPACE:
                    action_info['action'] = 'back'  # Go back in dialogue
                    return action_info

        # Handle mouse clicks (left-click)
        elif event.type == MOUSEBUTTONDOWN and event.button == 1:
            # Check if the pause button is clicked (except in the shop)
            if context != 'shop':
                pause_button_rect = d.draw_pause_button()  # Get pause button rectangle
                if pause_button_rect.collidepoint(event.pos):
                    action_info['action'] = 'pause'
                    return action_info

            # Handle selection in menus (combat/shop/dictionary)
            if context in ('combat', 'shop', 'dict') and option_rects:
                for i, rect in enumerate(option_rects):
                    if rect.collidepoint(event.pos):  # Check if a menu option was clicked
                        action_info.update({'action': 'select', 'option': i})
                        return action_info

        # Handle mouse movement (useful for hover effects or tracking cursor)
        elif event.type == MOUSEMOTION:
            action_info['pos'] = event.pos  # Store mouse position

    return action_info  # Return the event details dictionary