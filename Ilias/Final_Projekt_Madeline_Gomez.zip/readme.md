## OS
ProductName:		macOS\
ProductVersion:		15.2\
BuildVersion:		24C101

## Python Version
Python 3.12.4

## Problems
- The game runs just fine when not using gameEngineInterface
- using gameEngineInterface some problem occurs:
  - can not load fonts from 'Count_and_Conquer/MyAssets/Fonts', even when the content of the fonts are moved to the Count_and_Conquer folder and changing the path as follows: '/GameOfThrones.ttf'.
    - it generates the following error: File "/Users/teresamadeline/Downloads/GameEngineInterface/games/Count_and_Conquer/constant.py", line 47, in <module>
    fontObj = pygame.font.Font('/GameOfThrones.ttf', 48) # Title font not compatible with the integration thing
FileNotFoundError: No file '/GameOfThrones.ttf' found in working directory '/Users/teresamadeline/Downloads/GameEngineInterface'.
FileNotFoundError: No file 'Background.jpg' found in working directory '/Users/teresamadeline/Downloads/GameEngineInterface'.
  - can not load pictures from 'Count_and_Conquer/MyAssets/Images', even when the content of the Image are moved to the Count_and_Conquer folder and changing the path as follows: '\Background.jpg'.
    - it generates the following error: File "/Users/teresamadeline/Downloads/GameEngineInterface/games/Count_and_Conquer/combat.py", line 29, in __init__
    self.background = pygame.transform.scale(pygame.image.load('/Background.jpg'), FileNotFoundError: No file '/Background.jpg' found in working directory '/Users/teresamadeline/Downloads/GameEngineInterface'.

## Link for tutorial video
[Link to video](https://drive.google.com/file/d/1ISqyqNuu7zFl3H7U3pSCKBLZhUtGBwBS/view?usp=sharing)