# monster.py
# author: Paula Rios Gomez

import random
from hero import Hero
from constant import number_map, hundreds, thousands

# Monster
class Monster:
    def __init__(self, name: str, hero: Hero, type: str = "normal"):
        """
        Initializes a Monster attributes.
        :param name: name of monster as found in constant.py
        :param hero: hero class
        :param type: type of monster ("normal" or "boss")
        """
        self.name = name
        self.type = type
        self.hero = hero
        if type == "normal":
            self.reward = 5
            self.power = random.choice(list(number_map.keys()))  # Pick a random number
            self.base = int(str(abs(self.power))[0])  # Get the leftmost digit of the number
            self.word = number_map[self.power]  # Get corresponding word
        elif type == "boss":
            self.reward = 10
            base1, base2 = random.sample(hero.seen_bases, 2)
            thousand = base1 * 1000
            hundred = base2 * 100
            self.power = thousand + hundred  # Pick a random number
            self.base = 0
            self.word = thousands[thousand] + " ma " + hundreds[hundred] # Get corresponding word