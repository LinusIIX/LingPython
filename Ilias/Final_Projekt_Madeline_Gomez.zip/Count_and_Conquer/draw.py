# draw.py
# author: Teresa Madeline

import pygame
import constant as c


def draw_menu(selected, hovered=None):
    """
    Draws the main menu with selectable options.
    :param selected: (int) The index of the currently selected menu option.
    :param hovered: (int or None) The index of the currently hovered menu option, if any.
    :return: (list) A list of pygame.Rect objects representing the clickable option areas.
    """

    # Fill the screen with a black background
    c.DISPLAYSURF.fill(c.BLACK)

    # Draw the title at the top of the screen
    title_surface = c.fontObj.render(c.title, True, c.WHITE)
    title_rect = title_surface.get_rect(center=(c.WINDOWWIDTH // 2, 100))
    c.DISPLAYSURF.blit(title_surface, title_rect)

    # Calculate vertical positioning of menu options
    total_options_height = len(c.menu_options) * 50  # Each option has a height of 50 pixels
    starting_y = (c.WINDOWHEIGHT - total_options_height) // 2  # Center menu options vertically

    option_rects = []  # List to store option rectangles for interaction handling

    # Loop through menu options and draw them
    for i, option in enumerate(c.menu_options):
        # Ensure alpha list is properly sized for smooth fade-in effect
        if i >= len(c.option_alpha):
            c.option_alpha.append(0)
        if c.option_alpha[i] < 255:
            c.option_alpha[i] += 5  # Gradually increase opacity

        # Determine text and highlight colors based on selection or hover state
        color = c.BLACK if i == selected or i == hovered else c.WHITE
        highlight = c.WHITE if i == selected or i == hovered else c.BLACK

        # Create background rectangle for the option
        option_rect_bg = pygame.Rect(
            c.WINDOWWIDTH // 2 - 100,  # Center the rectangle horizontally
            starting_y + i * 50 - 25,  # Position each option with spacing
            200,  # Rectangle width
            50  # Rectangle height
        )
        pygame.draw.rect(c.DISPLAYSURF, highlight, option_rect_bg)  # Draw the rectangle

        # Render the menu option text
        option_surface = c.menuFont.render(option, True, color)
        option_surface.set_alpha(c.option_alpha[i])  # Apply fade-in effect

        # Center text within the option rectangle
        text_rect = option_surface.get_rect(center=option_rect_bg.center)
        c.DISPLAYSURF.blit(option_surface, text_rect)  # Draw text on screen

        option_rects.append(option_rect_bg)  # Store option rectangle for interaction detection

    pygame.display.update()  # Refresh the display to show the updated menu
    return option_rects  # Return list of option rectangles


def draw_pause_menu(selected, hovered=None):
    """
    Draws the pause menu with selectable options.
    :param selected: (int) The index of the currently selected pause menu option.
    :param hovered: (int or None) The index of the currently hovered option, if any.
    :return: (list) A list of pygame.Rect objects representing the clickable option areas.
    """

    # Fill the screen with a black background
    c.DISPLAYSURF.fill(c.BLACK)

    # Draw the "Pause" title at the top of the screen
    title_surface = c.fontObj.render("Pause", True, c.WHITE)
    title_rect = title_surface.get_rect(center=(c.WINDOWWIDTH // 2, 100))
    c.DISPLAYSURF.blit(title_surface, title_rect)

    # Calculate vertical positioning of pause menu options
    total_options_height = len(c.pause_options) * 50  # Each option has a height of 50 pixels
    starting_y = (c.WINDOWHEIGHT - total_options_height) // 2  # Center options vertically

    option_rects = []  # List to store option rectangles for interaction handling

    # Calculate maximum text width for dynamic button sizing
    max_width = max(c.menuFont.size(option)[0] for option in c.pause_options)
    padding = 20  # Padding around text for button size adjustment
    button_width = max_width + padding  # Adjust button width based on text size

    # Loop through pause menu options and draw them
    for i, option in enumerate(c.pause_options):
        # Ensure alpha list is properly sized for smooth fade-in effect
        if i >= len(c.option_alpha):
            c.option_alpha.append(0)
        if c.option_alpha[i] < 255:
            c.option_alpha[i] += 5  # Gradually increase opacity

        # Determine text and highlight colors based on selection or hover state
        color = c.BLACK if i == selected or i == hovered else c.WHITE
        highlight = c.WHITE if i == selected or i == hovered else c.BLACK

        # Create background rectangle for the option
        option_rect_bg = pygame.Rect(
            c.WINDOWWIDTH // 2 - (button_width // 2),  # Center the rectangle dynamically
            starting_y + i * 50 - 25,  # Position each option with spacing
            button_width,  # Dynamically sized width
            50  # Rectangle height
        )
        pygame.draw.rect(c.DISPLAYSURF, highlight, option_rect_bg)  # Draw the rectangle

        # Render the pause menu option text
        option_surface = c.menuFont.render(option, True, color)
        option_surface.set_alpha(c.option_alpha[i])  # Apply fade-in effect

        # Center text within the option rectangle
        text_rect = option_surface.get_rect(center=option_rect_bg.center)
        c.DISPLAYSURF.blit(option_surface, text_rect)  # Draw text on screen

        option_rects.append(option_rect_bg)  # Store option rectangle for interaction detection

    pygame.display.update()  # Refresh the display to show the updated pause menu
    return option_rects  # Return list of option rectangles

def draw_combat_menu(selected, hovered=None):
    """
    Draws the combat menu with selectable options.
    :param selected: (int) The index of the currently selected combat menu option.
    :param hovered: (int or None) The index of the currently hovered option, if any.
    :return: (list) A list of pygame.Rect objects representing the clickable option areas.
    """

    # Calculate positioning for the combat menu options
    total_options_height = len(c.combat_options) * 50  # Each option has a height of 50 pixels
    starting_y = c.WINDOWHEIGHT - total_options_height  # Position menu at bottom of screen

    option_rects = []  # List to store option rectangles for interaction handling

    # Calculate the maximum text width for dynamic button sizing
    max_width = max(c.subFont.size(option)[0] for option in c.combat_options)
    padding = 20  # Padding around text for button width adjustment
    button_width = max_width + padding  # Adjust button width based on text size

    # Loop through combat menu options and draw them
    for i, option in enumerate(c.combat_options):
        # Ensure alpha list is properly sized for smooth fade-in effect
        if i >= len(c.option_alpha):
            c.option_alpha.append(0)
        if c.option_alpha[i] < 255:
            c.option_alpha[i] += 5  # Gradually increase opacity

        # Determine text and highlight colors based on selection or hover state
        color = c.BLACK if i == selected or i == hovered else c.WHITE
        highlight = c.WHITE if i == selected or i == hovered else c.BLACK

        # Create background rectangle for the option (left-aligned)
        option_rect_bg = pygame.Rect(
            50 - padding // 2,  # Left-aligned position
            starting_y + i * 50 - 20,  # Positioning with spacing
            button_width,  # Dynamically sized width
            40  # Rectangle height
        )
        pygame.draw.rect(c.DISPLAYSURF, highlight, option_rect_bg)  # Draw the rectangle

        # Render the combat menu option text
        option_surface = c.subFont.render(option, True, color)
        option_surface.set_alpha(c.option_alpha[i])  # Apply fade-in effect

        # Center text within the option rectangle
        text_rect = option_surface.get_rect(center=option_rect_bg.center)
        c.DISPLAYSURF.blit(option_surface, text_rect)  # Draw text on screen

        option_rects.append(option_rect_bg)  # Store option rectangle for interaction detection

    pygame.display.update()  # Refresh the display to show the updated combat menu
    return option_rects  # Return list of option rectangles


def draw_shop_menu(selected, hovered=None):
    """
    Draws the shop menu with selectable options.
    :param selected: (int) The index of the currently selected shop menu option.
    :param hovered: (int or None) The index of the currently hovered option, if any.
    :return: (list) A list of pygame.Rect objects representing the clickable option areas.
    """

    # Calculate positioning for the shop menu options
    total_options_height = len(c.shop_option) * 50  # Each option has a height of 50 pixels
    starting_y = (c.WINDOWHEIGHT - total_options_height) // 2  # Center options vertically

    option_rects = []  # List to store option rectangles for interaction handling

    # Calculate the maximum text width for dynamic button sizing
    max_width = max(c.subFont.size(option)[0] for option in c.shop_option)
    padding = 80  # More padding for larger buttons
    button_width = max_width + padding  # Adjust button width based on text size

    # Loop through shop menu options and draw them
    for i, option in enumerate(c.shop_option):
        # Ensure alpha list is properly sized for smooth fade-in effect
        if i >= len(c.option_alpha):
            c.option_alpha.append(0)
        if c.option_alpha[i] < 255:
            c.option_alpha[i] += 5  # Gradually increase opacity

        # Determine text and highlight colors based on selection or hover state
        color = c.BLACK if i == selected or i == hovered else c.WHITE
        highlight = c.WHITE if i == selected or i == hovered else c.BLACK

        # Create background rectangle for the option (center-aligned)
        option_rect_bg = pygame.Rect(
            c.WINDOWWIDTH // 2 - (c.WINDOWWIDTH // 2 - 50),  # Center the rectangle
            starting_y + i * 50,  # Positioning with spacing
            button_width,  # Dynamically sized width
            40  # Rectangle height
        )
        pygame.draw.rect(c.DISPLAYSURF, highlight, option_rect_bg)  # Draw the rectangle

        # Render the shop menu option text
        option_surface = c.subFont.render(option, True, color)
        option_surface.set_alpha(c.option_alpha[i])  # Apply fade-in effect

        # Center text within the option rectangle
        text_rect = option_surface.get_rect(center=option_rect_bg.center)
        c.DISPLAYSURF.blit(option_surface, text_rect)  # Draw text on screen

        option_rects.append(option_rect_bg)  # Store option rectangle for interaction detection

    pygame.display.update()  # Refresh the display to show the updated shop menu
    return option_rects  # Return list of option rectangles

def draw_dict_menu(selected, hovered=None, show_replace=False, show_back=False, hero=None):
    """
    Draws the dictionary menu with selectable options.
    :param selected: (int) The index of the currently selected dictionary menu option.
    :param hovered: (int or None) The index of the currently hovered option, if any.
    :param show_replace: (bool) If True, shows "Yes" and "No" options.
    :param show_back: (bool) If True, only the "Back" option is displayed.
    :param hero: (object or None) If provided, displays the hero's dictionary entries.
    :return: (list) A list of pygame.Rect objects representing the clickable option areas.
    """

    # Determine options based on the current menu state
    if show_replace:
        options = ["Yes", "No"]
    elif show_back:
        options = ["Back"]
    elif hero and hero.dictionary:
        # Show dictionary entries as numbered options
        options = [f"{k}. {v}" for k, v in hero.dictionary.items()]
    else:
        options = c.dict_option  # Default options: ["View", "Add word", "Exit"]

    # Calculate dimensions
    total_options_height = len(options) * 50
    starting_y = (c.WINDOWHEIGHT - total_options_height) // 2

    option_rects = []  # List to store option rectangles for interaction detection
    max_width = max(c.subFont.size(option)[0] for option in options) if options else 0
    padding = 80  # Extra spacing for button width
    button_width = max_width + padding  # Dynamic button width based on text size

    # Loop through menu options and draw them
    for i, option in enumerate(options):
        # Ensure alpha list is properly sized for smooth fade-in effect
        if i >= len(c.option_alpha):
            c.option_alpha.append(0)
        if c.option_alpha[i] < 255:
            c.option_alpha[i] += 5  # Gradually increase opacity

        # Set colors based on selection or hover state
        color = c.BLACK if i == selected or i == hovered else c.WHITE
        highlight = c.WHITE if i == selected or i == hovered else c.BLACK

        # Adjust positioning based on content type
        if hero and hero.dictionary and not show_replace:
            # Left-align dictionary entries
            option_rect_bg = pygame.Rect(
                c.WINDOWWIDTH // 2 - (button_width // 2),
                starting_y + i * 50,
                button_width,
                40
            )
        else:
            # Center other options
            option_rect_bg = pygame.Rect(
                c.WINDOWWIDTH // 2 - (button_width // 2),
                starting_y + i * 50 + 150,
                button_width,
                40
            )

        pygame.draw.rect(c.DISPLAYSURF, highlight, option_rect_bg)  # Draw the rectangle

        # Special formatting for dictionary entries
        if hero and hero.dictionary and not show_replace:
            num, word = option.split(". ", 1)  # Split entry into number and word
            num_surface = c.textFont.render(num + ". ", True, c.BLACK)  # Render number
            word_surface = c.textFont.render(word, True, color)  # Render word

            # Combine surfaces for number and word
            combined_width = num_surface.get_width() + word_surface.get_width()
            combined_surface = pygame.Surface((combined_width, 40), pygame.SRCALPHA)
            combined_surface.blit(num_surface, (0, 0))
            combined_surface.blit(word_surface, (num_surface.get_width(), 0))

            text_rect = combined_surface.get_rect(center=(option_rect_bg.center))
            c.DISPLAYSURF.blit(combined_surface, text_rect)  # Draw combined text on screen
        else:
            option_surface = c.subFont.render(option, True, color)  # Render text
            text_rect = option_surface.get_rect(center=option_rect_bg.center)
            c.DISPLAYSURF.blit(option_surface, text_rect)  # Draw text on screen

        option_rects.append(option_rect_bg)  # Store option rectangle for interaction detection

    pygame.display.update()  # Refresh the display to show the updated dictionary menu
    return option_rects  # Return list of option rectangles


def draw_ending(victory: bool, selected, hovered=None):
    """
    Draws the ending screen with selectable options.
    :param victory: (bool) If True, displays "Victory". Otherwise, displays "Defeat".
    :param selected: (int) The index of the currently selected option.
    :param hovered: (int or None) The index of the currently hovered option, if any.
    :return: (list) A list of pygame.Rect objects representing the clickable option areas.
    """

    c.DISPLAYSURF.fill(c.BLACK)  # Clear the screen

    # Display title based on victory state
    title_text = "Victory" if victory else "Defeat"
    title_surface = c.fontObj.render(title_text, True, c.WHITE)
    title_rect = title_surface.get_rect(center=(c.WINDOWWIDTH // 2, c.WINDOWHEIGHT // 2 - 120))
    c.DISPLAYSURF.blit(title_surface, title_rect)  # Draw title on screen

    total_options_height = len(c.ending_options) * 50
    starting_y = (c.WINDOWHEIGHT - total_options_height) // 2

    option_rects = []  # List to store option rectangles for interaction detection
    # Calculate maximum text width for dynamic button sizing
    max_width = max(c.menuFont.size(option)[0] for option in c.ending_options)
    padding = 20  # Extra padding around text
    button_width = max_width + padding  # Dynamic button width

    # Loop through ending menu options and draw them
    for i, option in enumerate(c.ending_options):
        # Ensure alpha list is properly sized for smooth fade-in effect
        if i >= len(c.option_alpha):
            c.option_alpha.append(0)
        if c.option_alpha[i] < 255:
            c.option_alpha[i] += 5  # Gradually increase opacity

        # Determine text and highlight colors based on selection or hover state
        color = c.BLACK if i == selected or i == hovered else c.WHITE
        highlight = c.WHITE if i == selected or i == hovered else c.BLACK

        # Create background rectangle for the option
        option_rect_bg = pygame.Rect(
            c.WINDOWWIDTH // 2 - (button_width // 2),
            starting_y + i * 50 - 25,
            button_width,
            50
        )
        pygame.draw.rect(c.DISPLAYSURF, highlight, option_rect_bg)  # Draw the rectangle

        # Render option text
        option_surface = c.menuFont.render(option, True, color)
        option_surface.set_alpha(c.option_alpha[i])  # Apply fade-in effect

        # Center text within the option rectangle
        text_rect = option_surface.get_rect(center=option_rect_bg.center)
        c.DISPLAYSURF.blit(option_surface, text_rect)  # Draw text on screen

        option_rects.append(option_rect_bg)  # Store option rectangle for interaction detection

    pygame.display.update()  # Refresh the display to show the updated ending screen
    return option_rects  # Return list of option rectangles

def draw_pause_button():
    """
    Draws a pause button on the screen.
    :return: (pygame.Rect) The rectangle of the pause button for detecting clicks.
    """
    # https://www.pngegg.com/en/png-ynzgn
    # Load the pause button image
    pause_button = pygame.image.load('Assets/Images/pause-icon.png')

    # Resize the image to a smaller size
    pause_button = pygame.transform.scale(pause_button, (30, 30))

    # Set the button's position at the top-left corner
    pause_rect = pause_button.get_rect(topleft=(10, 10))

    # Draw the pause button on the screen
    c.DISPLAYSURF.blit(pause_button, pause_rect)

    return pause_rect  # Return the button's rect to detect clicks

def draw_text_box():
    """
    Creates a semi-transparent text box.
    :return: (tuple) A pygame.Surface for the box and its pygame.Rect position.
    """
    # Create a transparent surface for the text box
    box_surface = pygame.Surface((600, 100), pygame.SRCALPHA)

    # Set transparency (0 = fully transparent, 255 = fully opaque)
    box_surface.set_alpha(200)

    # Fill the surface with a semi-transparent black color
    box_surface.fill((0, 0, 0, 200))

    # Position the text box at the bottom-center of the screen
    box_rect = box_surface.get_rect(center=(c.WINDOWWIDTH // 2, c.WINDOWHEIGHT - 100))

    return box_surface, box_rect  # Return the surface and rectangle


def draw_text_rect(text: list[str], box_rect):
    """
    Creates text rectangles for each line of text within the text box.
    :param text: (list) A list of strings representing lines of text.
    :param box_rect: (pygame.Rect) The rectangle of the text box.
    :return: (list) A list of pygame.Rect objects for text placement.
    """
    text_rect = []

    for line in text:
        # Adjust height for multi-line text
        text_height = 11 * (line.count('\n') + 1)

        # Render text
        text_surface = c.textFont.render(line, True, c.WHITE)

        # Center text vertically within the box
        start_y = box_rect.centery - (text_height // 2)
        text_rect.append(text_surface.get_rect(center=(box_rect.centerx, start_y)))

    return text_rect

def draw_multiline_text(text, font, surface, rect, line_height, color=c.WHITE):
    """
    Renders multiline text onto a surface with color-coded bracketed sections.
    :param text: (str) The string to render.
    :param font: (pygame.font.Font) The font used for rendering.
    :param surface: (pygame.Surface) The surface to draw the text on.
    :param rect: (pygame.Rect) The rectangle defining text placement.
    :param line_height: (int) The height between lines.
    :param color: (tuple) RGB color of the text.
    """
    y = rect.top  # Starting Y position for text rendering
    in_bracket = False  # Track bracketed text state
    segments = []  # List of (text, color) segments
    current_color = color  # Default text color

    # Iterate through characters to identify special color changes
    for char in text:
        if char == '\n':
            # Store line break while preserving the color state
            segments.append(("\n", current_color))
            continue

        # Change text color when encountering brackets
        if char == '[':
            in_bracket = True
            current_color = c.GREEN  # Text inside brackets is green
        elif char == ']':
            in_bracket = False
            current_color = c.GREEN  # Keep closing bracket green

        # Add character to the segments list
        if segments and segments[-1][1] == current_color and segments[-1][0] != '\n':
            # Append character to the last segment if the color is the same
            segments[-1] = (segments[-1][0] + char, current_color)
        else:
            # Create a new segment if color changes
            segments.append((char, current_color))

    # Process segments into lines and render them
    current_line = []
    current_color = color
    y = rect.top  # Reset Y position for rendering

    for seg_text, seg_color in segments:
        if seg_text == "\n":
            # Render the current line
            render_line(current_line, font, surface, rect, y, line_height)
            current_line = []
            y += line_height  # Move to the next line
            current_color = seg_color  # Maintain the color for the next line
        else:
            current_line.append((seg_text, seg_color))

    # Render the last line if any text remains
    if current_line:
        render_line(current_line, font, surface, rect, y, line_height)


def render_line(segments, font, surface, rect, y, line_height):
    """
    Renders a single line of text with mixed colors.
    :param segments: (list) A list of (text, color) tuples for rendering.
    :param font: (pygame.font.Font) The font used for rendering.
    :param surface: (pygame.Surface) The surface to draw the text on.
    :param rect: (pygame.Rect) The bounding box for text placement.
    :param y: (int) The Y position for rendering the line.
    :param line_height: (int) The height between lines.
    """
    # Calculate total width of the text line for centering
    total_width = sum(font.size(text)[0] for text, _ in segments)
    start_x = rect.centerx - (total_width // 2)
    x = start_x

    for text, color in segments:
        # Render each segment with its respective color
        text_surface = font.render(text, True, color)
        surface.blit(text_surface, (x, y))  # Draw text at the current position
        x += text_surface.get_width()  # Move X position forward


def draw_text_input(surface, input_text: str):
    """
    Draws a text input box with blinking cursor.
    :param surface: (pygame.Surface) The surface to draw on.
    :param input_text: (str) The current text in the input box.
    """
    # Define input box dimensions and position
    box_width = 600
    box_height = 80
    x = (c.WINDOWWIDTH - box_width) // 2
    y = c.WINDOWHEIGHT - 150

    # Draw input box background
    pygame.draw.rect(surface, c.BLACK, (x, y, box_width, box_height), 0)
    pygame.draw.rect(surface, c.BLACK, (x, y, box_width, box_height), 2)  # Border

    # Render input text
    text_surf = c.textFont.render(input_text, True, c.WHITE)
    text_height = text_surf.get_height()

    # Calculate vertical position to center text
    vertical_padding = (box_height - text_height) // 2
    surface.blit(text_surf, (x + 20, y + vertical_padding))

    # Draw blinking cursor next to input text
    if pygame.time.get_ticks() % 1000 < 500:
        cursor_x = x + 20 + text_surf.get_width() + 2
        pygame.draw.line(surface, c.WHITE,
                         (cursor_x, y + vertical_padding),
                         (cursor_x, y + vertical_padding + text_height), 3)


def draw_text(text, font, surface, position, color):
    """
    Draws a single line of centered text.
    :param text: (str) The text to display.
    :param font: (pygame.font.Font) The font used for rendering.
    :param surface: (pygame.Surface) The surface to draw the text on.
    :param position: (tuple) The (x, y) coordinates for text placement.
    :param color: (tuple) RGB color of the text.
    """
    text_surface = font.render(text, True, color)  # Render text to a surface
    text_rect = text_surface.get_rect(center=position)  # Center the text at the given position
    surface.blit(text_surface, text_rect)  # Draw text on screen