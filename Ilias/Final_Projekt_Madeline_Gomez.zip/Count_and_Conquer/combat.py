# combat.py
# author: Teresa Madeline and Paula Rios Gomez

import random
from constant import *
from monster import Monster
from shop import *
import animation as a

class CombatSystem:
    def __init__(self, hero: Hero):
        # Initialize combat system with a reference to the hero
        self.hero = hero
        self.current_enemy = None  # No enemy at the start
        self.waves = 0  # Keeps track of the wave number
        self.stage = 0  # Stage number for tracking overall progression
        self.input_text = ''  # Store text input from the player
        self.time = 0.0  # Timer for combat-related activities
        self.victory_time = 0.0  # Time when the victory occurred
        self.menu_active = False  # Flag to indicate if the menu is active
        self.in_boss_fight = False  # Flag to indicate if the player is in a boss fight
        self.input_active = False  # Flag to track if player input is active
        self.victory = False  # Flag to check if the player won
        self.is_drawing = False  # Flag for handling drawing state
        self.error_start_time = None  # Tracks when the incorrect word was entered
        self.pending_shop_transition = False  # Flag for shop transition
        self.background = pygame.transform.scale(pygame.image.load('Assets/Images/Background.jpg'),
                                                 (WINDOWWIDTH, WINDOWHEIGHT))  # Background image for the fight screen
        self.spawn_enemy()  # Call to spawn the first enemy

    def spawn_enemy(self):
        """
        Spawns a new enemy based on the current wave. If the wave is less than 4,
        a regular enemy is spawned. If the wave is 4 or more, a boss enemy is spawned.
        :return:
        """
        if self.waves < 4:
            # If the wave number is less than 2, spawn a regular enemy
            name = random.choice(list(enemies.keys()))  # Randomly select an enemy name from the enemies dictionary
            self.current_enemy = Monster(name,
                                         self.hero)  # Create a new Monster object with the selected name and the hero
            self.waves += 1  # Increment the wave counter
        else:
            # If wave number is 2 or more, spawn a boss enemy
            self.current_enemy = Monster((random.choice(list(bosses.keys()))), self.hero,
                                         "boss")  # Select a random boss and create a new Monster object
            self.in_boss_fight = True  # Set the flag indicating that the player is in a boss fight

    def handle_input(self, event_info: dict):
        """
        Handles the player's input during combat, such as pressing the 'back' button, typing text,
        or submitting text. This function processes the input and determines the next action.
        :param event_info: Dictionary containing the input event details (action and additional data)
        :return:
        """
        # Check if the 'back' action is triggered (e.g., ESC key)
        if event_info['action'] == 'back':
            self.input_active = False  # Deactivate text input mode
            self.menu_active = True  # Activate the menu (return to menu screen)
            self.input_text = ''  # Clear the input text field
            return  # Exit the function

        # Check if the 'text_input' action is triggered (i.e., player is typing text)
        if event_info['action'] == 'text_input':
            self.input_text += event_info['unicode']  # Append the typed character to the input text

        # Check if the 'backspace' action is triggered (i.e., player is deleting text)
        elif event_info['action'] == 'backspace':
            # Delete continuously while backspace is held
            self.input_text = self.input_text[:-1]  # Remove the last character from the input text

        # Check if the 'submit_text' action is triggered (i.e., player presses Enter to submit the text)
        elif event_info['action'] == 'submit_text':
            self.input_active = False  # Deactivate text input mode
            self.menu_active = True  # Activate the menu (return to menu screen)
            return self.process_answer()  # Process the answer by calling process_answer() function

    def process_answer(self):
        """
        Processes the player's answer input and determines the outcome of the combat.
        If the player's input matches the enemy's word, the player wins. If not, the player takes damage.
        :return: Depending on the result, either the victory handler or damage handler is called.
        """
        self.input_active = False  # Deactivate text input mode
        # Check if the player's input matches the enemy's word
        if self.input_text.lower() == self.current_enemy.word:
            self.input_text = ''  # Clear the input text field
            return self.handle_victory()  # Call the handle_victory method if the player wins
        else:
            self.input_text = ''  # Clear the input text field
            return self.handle_damage()  # Call the handle_damage method if the player loses

    def handle_victory(self):
        """
        Handles the player's victory after successfully defeating an enemy.
        The player gains coins and adds a new base to their list. If in a boss fight, the stage is updated.
        :return: The next action after victory (either end the game or go to the shop).
        """
        self.hero.increase_coin(self.current_enemy.reward)  # Increase the player's coins based on enemy reward
        self.hero.add_base_to_list(self.current_enemy.base)  # Add the enemy's base to the player's list
        self.victory = True  # Set victory flag to True
        self.victory_time = pygame.time.get_ticks()  # Store the time when the victory occurred
        self.menu_active = False  # Deactivate the menu

        # Check if it's a boss fight and if the player has defeated the boss
        if self.in_boss_fight:
            self.waves = 0  # Reset the wave counter
            self.stage += 1  # Increment the stage
            self.in_boss_fight = False  # End the boss fight

            # Check if the player has completed all stages
            if self.stage >= 3:
                # print("victory")  # Print victory message
                return ["end", True]  # End the game and mark the player as victorious
            return "shop"  # If not all stages are completed, transition to the shop

        return "fight"  # Continue fighting if not in a boss fight

    def handle_damage(self):
        """
        Handles the player's defeat when the input does not match the enemy's word.
        The player takes damage, and if the player's health reaches 0, the game ends.
        :return: The next action after taking damage (either continue or end the game).
        """
        self.victory = False  # Set victory flag to False
        self.victory_time = pygame.time.get_ticks()  # Record the time of the defeat
        self.menu_active = False  # Deactivate the menu

        # Check if the player has taken enough damage to be defeated
        if self.hero.take_damage():
            # print("defeat")  # Print defeat message
            return ["end", False]  # End the game and mark the player as defeated

        return "wrong"  # Return "wrong" if the player has not been defeated but the input was incorrect

    def draw(self, surface, time, entry_time, n, i):
        """
        Draws the combat scene, including the monster, text boxes, and victory or error messages.
        This method handles drawing the background, enemy animation, text for the player,
        and displaying the current state of the combat, such as victory or error messages.
        :param surface: The surface on which to draw the game visuals (usually the game window).
        :param time: The current time used for animations.
        :param entry_time: The time when the enemy appeared, used to control animations.
        :param n: The number of characters to be displayed in the current text frame.
        :param i: The index of the text list that is currently being drawn.
        :return:
        """
        self.menu_active = False  # Disable menu interaction while drawing the combat screen
        self.is_drawing = True  # Set the drawing state to true, indicating drawing is happening

        # Clear the screen and prepare for new content
        self.clear(surface, time)

        # Draw the enemy's animation (monster)
        a.monster_animation(self.current_enemy.name, self.current_enemy.type, time, entry_time)

        # Draw the text box
        box_surface, box_rect = d.draw_text_box()

        # Initialize the text list to store messages to be displayed
        text: list[str] = []
        if self.victory:
            # If the player won, display a victory message
            text.append(f"You have defeated the enemy!\n[You have gained some coins.]")
        else:
            # If not in victory state, display enemy-related text
            if self.current_enemy.type == 'normal' and self.current_enemy.base not in self.hero.seen_bases:
                text.append(f"A {self.current_enemy.name} appears with the power of {self.current_enemy.power}!\n"
                            f"The word \"{c.base.get(self.current_enemy.base)}\" is branded upon their skin.")
            else:
                text.append(f"A {self.current_enemy.name} appears with the power of {self.current_enemy.power}!")

            # Display error message if the player has entered the wrong word
            if hasattr(self, 'error_start_time') and self.error_start_time is not None:
                text.append("You have entered the incorrect word.")

        # Render text
        if n < len(text[i]) and i < 2:
            # If the text has not been fully written yet, display part of it
            text_rect = d.draw_text_rect(text, box_rect)  # Draw the text box rectangle
            # Blit (copy) the text box to the screen
            c.DISPLAYSURF.blit(box_surface, box_rect)

            # Display the partial text up to the current character limit (n)
            partial_text = text[i][:n]  # Get the current portion of the text to display
            d.draw_multiline_text(partial_text, c.textFont, c.DISPLAYSURF, text_rect[i], 18)

        else:
            # If the text is complete or ready to be fully displayed
            box_rect.x += 100  # Shift the text box slightly for effect (moving horizontally)
            text_rect = d.draw_text_rect(text, box_rect)  # Redraw the updated text box
            c.DISPLAYSURF.blit(box_surface, box_rect)  # Blit the text box to the screen

            # Display the full text up to the character limit (n)
            partial_text = text[i][:n]  # Get the current portion of the text to display
            d.draw_multiline_text(partial_text, c.textFont, c.DISPLAYSURF, text_rect[i], 18)

            # Enable menu interaction after text is fully drawn
            self.menu_active = True

            # If text input is active, clear the screen and prepare for new input
            if self.input_active:
                self.clear(surface, time)  # Clear the screen
                a.monster_animation(self.current_enemy.name, self.current_enemy.type, time,
                                    entry_time)  # Draw the enemy again

            # Display the victory message for a brief period (3 seconds)
            if pygame.time.get_ticks() - self.victory_time < 3000:
                self.menu_active = False  # Disable menu during the victory message
                self.clear(surface, time)  # Clear the screen
                box_rect.x -= 100  # Shift the text box back to its original position
                text_rect = d.draw_text_rect(text, box_rect)  # Redraw the text box
                c.DISPLAYSURF.blit(box_surface, box_rect)  # Blit the text box to the screen
                partial_text = text[i][:n]  # Get the current portion of the text to display
                d.draw_multiline_text(partial_text, c.textFont, c.DISPLAYSURF, text_rect[i], 18)

    def clear(self, surface, time):
        """
        Clears the screen and redraws all the necessary UI components such as the background,
        hero, health (heart) and coins animations, and pause button.
        :param surface: The surface where the game visuals will be drawn (usually the main game window).
        :param time: The current time used for animations (e.g., for heart and coin animation).
        :return:
        """
        # Draw the background to the surface (essentially the game background)
        surface.blit(self.background, (0, 0))

        # Draw the pause button on the screen
        d.draw_pause_button()

        # Draw the heart animation representing the hero's health
        a.heart_animation(self.hero.hp, time)

        # Draw the coin animation, showing the number of coins the hero has
        a.coin_animation(time, num_coin=self.hero.coin)

        # Draw the hero's animation (in this case, showing the hero facing backward)
        a.hero_animation("back", time, c.WINDOWWIDTH - (c.WINDOWWIDTH - 220))

    def update(self):
        """
        Updates the current state of the combat, checking for the existence of the current enemy
        and handling potential issues like missing enemies or victory states.
        :return:
        """
        # If there is no current enemy and no victory condition is met, print the enemy name
        if not self.current_enemy and not self.victory:
            print(self.current_enemy.name)  # This may be used for debugging purposes or error handling.
