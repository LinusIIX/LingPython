# animation.py
# author: Teresa Madeline

import math
import pygame
import constant as c


def hero_animation(profile: str, time, x, y=c.WINDOWHEIGHT):
    """
    Animates the hero sprite with a pulsing effect based on time.
    :param profile: (str) The hero's current stance ('front', 'back', 'shop').
    :param time: (float) Time variable for animation effects.
    :param x: (int) X-coordinate for hero positioning.
    :param y: (int, optional) Y-coordinate for hero positioning. Defaults to bottom of the window.
    """

    original_width, original_height = 0, 0

    # https://www.pngegg.com/en/png-tkarq
    # Load the hero sprite based on profile
    if profile == "front":
        hero = pygame.image.load('Assets/Images/hero-front.png')
        size = 600 + 5 * math.sin(time) # Pulsing size effect
    elif profile == "back":
        hero = pygame.image.load('Assets/Images/hero-back.png')
        size = 500 + 5 * math.sin(time) # Pulsing size effect
    elif profile == "shop":
        hero = pygame.image.load('Assets/Images/hero-front.png')
        size = 1000 + 5 * math.sin(time) # Pulsing size effect

    original_width, original_height = hero.get_size()

    # Maintain aspect ratio when scaling
    new_height = int(size)
    new_width = int(original_width * (new_height / original_height))

    # Scale and position the hero sprite
    scaled_hero = pygame.transform.scale(hero, (new_width, new_height))
    hero_rect = scaled_hero.get_rect(midbottom=(x, y))

    # Draw hero on screen
    c.DISPLAYSURF.blit(scaled_hero, hero_rect)

def monster_animation(name, type, time, entry_time):
    """
    Animates monsters with a pulsing effect.
    :param name: (str) The monster's name (e.g., 'Dragon', 'Direwolf').
    :param type: (str) The monster's category ('normal' or 'boss').
    :param time: (float) Time variable for animation effects.
    :param entry_time: (float) Controls the sliding animation duration.
    """
    # Load the correct monster image from predefined dictionaries
    if type == "normal":
        monster = pygame.image.load(c.enemies[name])
    else:
        monster = pygame.image.load(c.bosses[name])

    original_width, original_height = monster.get_size()

    # Assign pulsing sizes based on monster type
    if name == "Dragon":
        size = 600 + 5 * math.sin(time+2)
    elif name in ("Direwolf", "Night King"):
        size = 400 + 5 * math.sin(time+2)
    else:
        size = 300 + 5 * math.sin(time+2)

    # Maintain aspect ratio when scaling
    new_height = int(size)
    new_width = int(original_width * (new_height / original_height))

    scaled_monster = pygame.transform.scale(monster, (new_width, new_height))

    final_x = c.WINDOWWIDTH - 200  # Final resting position
    start_x = c.WINDOWWIDTH + 100  # Start from off-screen

    # Smooth transition: Interpolate between start_x and final_x
    slide_speed = 500  # Adjust slide speed (higher = faster)
    entry_progress = min(entry_time / slide_speed, 1)  # Clamp between 0 and 1
    current_x = start_x - (start_x - final_x) * entry_progress  # Linear interpolation

    # Position monster towards the right side of the screen
    monster_rect = scaled_monster.get_rect(midbottom=(current_x, c.WINDOWHEIGHT - 60))

    # Draw monster on screen
    c.DISPLAYSURF.blit(scaled_monster, monster_rect)

def heart_animation(hp, time, x=None, y=None, shrink=False, growing=False, shrink_timer=0):
    """
    Animates heart icons representing player health with pulsing, shrinking, and growing effects.
    :param hp: (int) Current health points.
    :param time: (float) Time variable for pulsing effect.
    :param x: (int, optional) X-coordinate for heart placement.
    :param y: (int, optional) Y-coordinate for heart placement.
    :param shrink: (bool) Whether the hearts are shrinking.
    :param growing: (bool) Whether the hearts are growing.
    :param shrink_timer: (int) Timer to control the shrink/grow effect.
    :return: (bool) Returns True if growth is complete, False otherwise.
    """
    base_size = 100
    shrink_speed = 5
    grow_speed = 5
    min_size = 5
    max_size = 100

    # https://www.pngegg.com/en/png-vompn
    heart = pygame.image.load('Assets/Images/heart-icon.png')
    horizontal_spacing = 40  # Distance between hearts

    # Default positioning
    if x is None and y is None:
        x = c.WINDOWWIDTH // 2
        y = 50

    growth_complete = False

    # Handle shrinking and growing effects
    if shrink:
        size = max(min_size, base_size - shrink_speed * shrink_timer)
        if size == min_size:
            return True  # Shrinking complete
    elif growing:
        size = min(max_size, min_size + grow_speed * shrink_timer)
        if size == max_size:
            growth_complete = True  # Growth complete
    else:
        size = base_size + 10 * math.sin(time)  # Pulsing effect

    # Generate hearts based on current HP
    positions = []
    if hp > 0:
        start_x = x - ((hp - 1) * horizontal_spacing) // 2  # Center hearts
        positions = [(start_x + i * horizontal_spacing, y) for i in range(hp)]

    # Draw hearts
    for pos in positions:
        scaled_heart = pygame.transform.scale(heart, (int(size), int(size)))
        heart_rect = scaled_heart.get_rect(center=pos)
        c.DISPLAYSURF.blit(scaled_heart, heart_rect)

    return growth_complete

def coin_animation(time, x=None, y=None, shrink=False, growing=False, shrink_timer=0, num_coin=0):
    """
        Animates the coin icon with pulsing, shrinking, and growing effects.
        :param time: (float) Time variable for pulsing effect.
        :param x: (int, optional) X-coordinate for coin placement.
        :param y: (int, optional) Y-coordinate for coin placement.
        :param shrink: (bool) Whether the coin is shrinking.
        :param growing: (bool) Whether the coin is growing.
        :param shrink_timer: (int) Timer to control the shrink/grow effect.
        :param num_coin: (int) Number of coins to display.
        :return: (bool) Returns True if growth is complete, False otherwise.
        """
    base_size = 25
    shrink_speed = 5
    grow_speed = 5
    min_size = 5
    max_size = 25

    # https://www.pngegg.com/en/png-edbdk
    coin = pygame.image.load('Assets/Images/coin-icon.png')

    # Default positioning
    if x is None and y is None:
        x = c.WINDOWWIDTH // 2 - 20
        y = 90

    growth_complete = False

    # Handle shrinking and growing effects
    if shrink:
        size = max(min_size, base_size - shrink_speed * shrink_timer)
        if size == min_size:
            return True  # Shrinking complete
    elif growing:
        size = min(max_size, min_size + grow_speed * shrink_timer)
        if size == max_size:
            growth_complete = True  # Growth complete
    else:
        size = max(1, abs(int(base_size * math.sin(time))))  # Pulsing effect

    # Scale and draw the coin
    scaled_coin = pygame.transform.scale(coin, (int(size), int(base_size)))
    coin_rect = scaled_coin.get_rect(center=(x, y))
    c.DISPLAYSURF.blit(scaled_coin, coin_rect)

    # Display coin count as text
    coin_text = c.textFont.render(str(num_coin), True, c.WHITE)
    text_rect = coin_text.get_rect(midleft=(x + 20, coin_rect.centery))
    c.DISPLAYSURF.blit(coin_text, text_rect)

    return growth_complete