# menu.py
# author: Teresa Madeline

import pygame, sys
from pygame.locals import *
import draw as d
import constant as c
import eventHandler as e
from combat import CombatSystem
from hero import Hero


def main_menu(hero: Hero, combat: CombatSystem):
    """
    Displays the main menu of the game, where the user can choose to start a new game or quit.
    The function handles mouse hover effects, keyboard navigation, and mouse click events
    to allow the user to interact with the menu options.
    :param hero: The player character (Hero) object.
    :param combat: The combat system (CombatSystem) object.
    :return: The function returns the appropriate function or action depending on the player's selection:
             - If 'Start Game' is selected, returns the `hero_intro` function.
             - If 'Quit' is selected, quits the game and exits the program.
    """
    # Initialize the transparency of the menu options (for hover effects)
    c.option_alpha = [0] * len(c.menu_options)

    while True:
        # Get mouse position for hover effect
        mouse_x, mouse_y = pygame.mouse.get_pos()

        # Draw the menu and get the option rectangles for click detection
        option_rects = d.draw_menu(c.selected_option)

        hovered_option = None

        # Check which option the mouse is hovering over
        for i, rect in enumerate(option_rects):
            if rect.collidepoint(mouse_x, mouse_y):
                hovered_option = i
                break

        # If the mouse is hovering over another option, unselect the current one
        if hovered_option is not None and hovered_option != c.selected_option:
            c.selected_option = None  # Unselect current option when hovering over another one

        # Re-render the menu with the updated hover state
        option_rects = d.draw_menu(c.selected_option, hovered=hovered_option)  # Highlight the hovered option

        # Event loop to handle user interactions
        for event in pygame.event.get():
            if event.type == QUIT:
                # If the user closes the window, exit the game
                return sys.exit

            # Handle keyboard navigation if an option is selected
            elif event.type == KEYDOWN:
                if c.selected_option is None:
                    # No option is selected, allow navigation to highlight options
                    if event.key == K_UP:
                        c.selected_option = 0  # Highlight the first option
                    elif event.key == K_DOWN:
                        c.selected_option = 0  # Highlight the first option
                elif event.key == K_UP:
                    # Move selection up through the options
                    c.selected_option = (c.selected_option - 1) % len(c.menu_options)
                elif event.key == K_DOWN:
                    # Move selection down through the options
                    c.selected_option = (c.selected_option + 1) % len(c.menu_options)
                elif event.key == K_RETURN:  # Enter key to select an option
                    if c.selected_option == 0:  # Start Game
                        # Import hero_intro and return to start the game
                        from main import hero_intro
                        return hero_intro
                    elif c.selected_option == 1:  # Quit
                        pygame.quit()
                        return sys.exit

            # Handle mouse click to select an option
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  # Left mouse button
                mouse_pos = pygame.mouse.get_pos()  # Get mouse position
                for i, option_rect in enumerate(option_rects):
                    if option_rect.collidepoint(mouse_pos):  # Check if mouse is over the option
                        if i == 0:  # Start Game
                            from main import hero_intro
                            return hero_intro
                        elif i == 1:  # Quit
                            pygame.quit()
                            return sys.exit

        # Update the display to reflect changes (redraw the menu)
        pygame.display.update()
        # Control the frame rate of the game
        c.FPSCLOCK.tick(c.FPS)


def pause_menu(prev_screen):
    """
    Displays the pause menu where the player can resume the game, access options, or quit to the main menu.
    The function handles mouse hover effects, keyboard navigation, and mouse clicks to allow the player
    to interact with the menu options and choose one of the available actions.
    :param prev_screen: The previous screen (usually the game screen) that will be returned to upon resuming.
    :return: The function returns the appropriate screen or action based on the player's selection:
             - If 'Resume Game' is selected, returns to the previous screen.
             - If 'Options' is selected, quits the game (for demonstration purposes).
             - If 'Quit to Main Menu' is selected, returns to the main menu.
    """
    # Initialize the transparency of the pause menu options (for hover effects)
    c.option_alpha = [0] * len(c.pause_options)

    while True:
        # Get mouse position for hover effect
        mouse_x, mouse_y = pygame.mouse.get_pos()

        # Draw the pause menu and get the option rectangles for click detection
        option_rects = d.draw_pause_menu(c.selected_option)

        hovered_option = None

        # Check which option the mouse is hovering over
        for i, rect in enumerate(option_rects):
            if rect.collidepoint(mouse_x, mouse_y):
                hovered_option = i
                break

        # If the mouse is hovering over another option, unselect the current one
        if hovered_option is not None and hovered_option != c.selected_option:
            c.selected_option = None  # Unselect current option when hovering over another one

        # Re-render the menu with the updated hover state (highlight hovered option)
        option_rects = d.draw_pause_menu(c.selected_option, hovered=hovered_option)

        # Event loop to handle user interactions
        for event in pygame.event.get():
            if event.type == QUIT:
                # If the user closes the window, exit the game
                return sys.exit

            # Handle keyboard navigation if an option is selected
            elif event.type == KEYDOWN:
                if c.selected_option is None:
                    # No option is selected, allow navigation to highlight options
                    if event.key == K_UP:
                        c.selected_option = 0  # Highlight the first option
                    elif event.key == K_DOWN:
                        c.selected_option = 0  # Highlight the first option
                elif event.key == K_UP:
                    # Move selection up through the options
                    c.selected_option = (c.selected_option - 1) % len(c.pause_options)
                elif event.key == K_DOWN:
                    # Move selection down through the options
                    c.selected_option = (c.selected_option + 1) % len(c.pause_options)
                elif event.key == K_ESCAPE:  # ESC key to return to the previous screen
                    return prev_screen
                elif event.key == K_RETURN:  # Enter key to select an option
                    if c.selected_option == 0:  # Resume Game
                        # print("Resume Game")
                        return prev_screen
                    elif c.selected_option == 1:  # Open options
                        # print("Options / Quit Game")
                        # This is where the options menu or quit action would happen
                        return sys.exit
                    elif c.selected_option == 2:  # Quit to main menu
                        # print("Main Menu")
                        return main_menu

            # Handle mouse click to select an option
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  # Left mouse button
                mouse_pos = pygame.mouse.get_pos()  # Get mouse position
                for i, option_rect in enumerate(option_rects):
                    if option_rect.collidepoint(mouse_pos):  # Check if mouse is over the option
                        if i == 0:  # Resume Game
                            return prev_screen
                        elif i == 1:  # Open options
                            # This would open the options menu or quit the game
                            return sys.exit
                        elif i == 2:  # Quit to main menu
                            return main_menu

        # Update the display to reflect changes (redraw the menu)
        pygame.display.update()
        # Control the frame rate of the game
        c.FPSCLOCK.tick(c.FPS)


def combat_menu():
    """
    Displays and handles interactions for the combat menu.
    This function is responsible for displaying the combat options, handling both mouse and keyboard navigation,
    and determining the selected action. The options include actions like 'Attack', 'Dictionary', 'Reroll', and 'Surrender'.
    :return: The selected action, which can be 'attack', 'dictionary', 'reroll', 'surrender', or 'pause'
             (if the pause action was selected). If no action is selected, it returns 0.
    """
    # Set key repeat parameters for smooth keyboard navigation in the menu
    pygame.key.set_repeat(c.KEY_REPEAT_DELAY, c.KEY_REPEAT_INTERVAL)

    # Get mouse position to handle hover effects
    mouse_x, mouse_y = pygame.mouse.get_pos()

    # Draw the combat menu and get option rectangles for click detection
    option_rects = d.draw_combat_menu(c.selected_option)

    # Handle hover effect: determine which option the mouse is hovering over
    hovered_option = 0  # Default to the first option
    for i, rect in enumerate(option_rects):
        if rect.collidepoint(mouse_x, mouse_y):
            hovered_option = i
            break

    # Update selection only if not using keyboard navigation
    if not c.using_keyboard_nav:
        if hovered_option is not None and hovered_option != c.selected_option:
            c.selected_option = hovered_option

    # Process events (keyboard and mouse input) during the combat menu interaction
    event_info = e.handle_events(context='combat', option_rects=option_rects)

    # Initialize the default selected action (0 means no action yet)
    selected_action = 0

    if event_info is not None:
        if event_info['action'] == 'quit':
            # Exit the game if 'quit' action is triggered
            sys.exit()
        elif event_info['action'] == 'pause':
            # Handle pausing the game
            pygame.key.set_repeat(0)  # Disable key repeat on pause
            return 'pause'
        elif event_info['action'] == 'navigate':
            # Handle keyboard navigation through options
            c.using_keyboard_nav = True  # Flag that we're using keyboard navigation
            direction = event_info['direction']
            new_selection = c.selected_option if c.selected_option is not None else 0

            # Update the selected option based on the direction of navigation
            if direction == 'up':
                new_selection = (new_selection - 1) % len(c.combat_options)
            else:
                new_selection = (new_selection + 1) % len(c.combat_options)

            c.selected_option = new_selection
        elif event_info['action'] == 'select':
            # Handle selection of an action
            selected_option = event_info.get('option', c.selected_option)
            if selected_option is not None:
                pygame.key.set_repeat(0)  # Reset key repeat on selection
                c.using_keyboard_nav = False  # Switch off keyboard navigation
                actions = ['attack', 'dictionary', 'reroll', 'surrender']  # List of available actions
                if selected_option < len(actions):
                    selected_action = actions[selected_option]
                    c.selected_option = None  # Clear selection after an action
                    return selected_action

    # Update only the area where the menu is displayed to improve performance
    pygame.display.update(option_rects)

    # Return the selected action (0 if no action has been selected)
    return selected_action


def shop_menu():
    """
    Displays and handles interactions for the shop menu.
    This function is responsible for showing the shop options (e.g., buying, selling, quitting),
    and processing user inputs for navigation and selection. The user can navigate using the mouse
    or keyboard to select a desired option.
    :return: The selected action, such as 'buy', 'sell', 'quit', or 'pause' (if the pause action is selected).
             If no action is selected, it returns None.
    """
    # Set key repeat parameters to allow smooth keyboard navigation in the menu
    pygame.key.set_repeat(c.KEY_REPEAT_DELAY, c.KEY_REPEAT_INTERVAL)

    # Get mouse position for hover effect on menu options
    mouse_x, mouse_y = pygame.mouse.get_pos()

    # Draw the shop menu and get option rectangles for hitbox detection
    option_rects = d.draw_shop_menu(c.selected_option)

    # Handle mouse hover: determine which option the mouse is hovering over
    hovered_option = 0  # Default to the first option if no hover detected
    for i, rect in enumerate(option_rects):
        if rect.collidepoint(mouse_x, mouse_y):
            hovered_option = i
            break

    # Update the selection if using mouse hover
    if not c.using_keyboard_nav:
        if hovered_option is not None and hovered_option != c.selected_option:
            c.selected_option = hovered_option

    # Process events (keyboard and mouse input) for menu interactions
    event_info = e.handle_events(context='shop', option_rects=option_rects)

    # Initialize selected_action as None (no action selected yet)
    selected_action = None

    if event_info is not None:
        if event_info['action'] == 'quit':
            # Exit the game if the 'quit' action is triggered
            sys.exit()
        elif event_info['action'] == 'pause':
            # Handle pausing the game
            pygame.key.set_repeat(0)  # Disable key repeat on pause
            return 'pause'
        elif event_info['action'] == 'navigate':
            # Handle keyboard navigation through shop menu options
            c.using_keyboard_nav = True  # Flag that we're using keyboard navigation
            direction = event_info['direction']
            new_selection = c.selected_option if c.selected_option is not None else 0

            # Update the selected option based on the direction (up or down)
            if direction == 'up':
                new_selection = (new_selection - 1) % len(c.shop_option)
            else:
                new_selection = (new_selection + 1) % len(c.shop_option)

            c.selected_option = new_selection
        elif event_info['action'] == 'select':
            # Handle the selection of an action from the menu
            selected_option = event_info.get('option', c.selected_option)
            if selected_option is not None:
                pygame.key.set_repeat(0)  # Reset key repeat
                c.using_keyboard_nav = False  # Disable keyboard navigation after selection
                actions = c.shop_option  # List of available shop actions
                if selected_option < len(actions):
                    selected_action = actions[selected_option]
                    c.selected_option = None  # Clear the selection after an action
                    return selected_action

    # Update only the area where the menu is drawn to optimize performance
    pygame.display.update(option_rects)

    # Return the selected action (None if no action selected)
    return selected_action


def dict_menu(hero=None, show_replace=False, show_back=False):
    """
    Displays the dictionary menu and handles user input for navigation and selection.
    Depending on the state of the menu, the options will be dynamically adjusted (e.g., showing
    dictionary entries, "Back", or "Yes"/"No" options for replacing words). The function handles mouse
    and keyboard inputs, allowing users to navigate through the options and select an action.
    :param hero: The hero object containing the dictionary entries. Default is None.
    :param show_replace: Boolean flag to indicate whether the "Yes"/"No" replacement options should be shown.
    :param show_back: Boolean flag to indicate whether the "Back" option should be displayed.
    :return: The selected action based on the user's input.
    """
    # Set key repeat parameters to allow smooth navigation in the menu
    pygame.key.set_repeat(c.KEY_REPEAT_DELAY, c.KEY_REPEAT_INTERVAL)

    # Determine the current options based on the menu state
    if show_replace:
        options = ["Yes", "No"]
    elif show_back:
        options = ["Back"]
    elif hero and hero.dictionary:
        options = list(hero.dictionary.keys())  # Show dictionary keys if hero has dictionary
    else:
        options = c.dict_option  # Default options from c.dict_option

    # Get mouse position for hover effects
    mouse_x, mouse_y = pygame.mouse.get_pos()

    # Draw the dictionary menu and get option rectangles for hitbox detection
    option_rects = d.draw_dict_menu(c.selected_option,
                                    hero=hero,
                                    show_replace=show_replace,
                                    show_back=show_back)

    # Handle mouse hover: determine which option the mouse is hovering over
    hovered_option = None
    for i, rect in enumerate(option_rects):
        if rect.collidepoint(mouse_x, mouse_y):
            hovered_option = i
            break

    # Update the selection if using mouse hover
    if not c.using_keyboard_nav and hovered_option is not None:
        c.selected_option = hovered_option

    # Process events (keyboard and mouse input) for menu interactions
    event_info = e.handle_events(context='dict', option_rects=option_rects)
    selected_action = None

    if event_info:
        if event_info['action'] == 'quit':
            # Exit the game if the 'quit' action is triggered
            sys.exit()
        elif event_info['action'] == 'navigate':
            # Handle keyboard navigation through menu options
            c.using_keyboard_nav = True  # Set flag for keyboard navigation
            if options:  # Ensure there are options to navigate
                new_selection = c.selected_option if c.selected_option is not None else 0
                if event_info['direction'] == 'up':
                    # Move selection up, but ensure it doesn't go below 0
                    new_selection = max(0, new_selection - 1)
                else:
                    # Move selection down, but ensure it doesn't exceed options length
                    new_selection = min(len(options) - 1, new_selection + 1)
                c.selected_option = new_selection
        elif event_info['action'] == 'select':
            # Handle option selection
            selected_index = event_info.get('option', c.selected_option)
            if selected_index is not None and selected_index < len(options):
                # Handle dictionary key selection (for numbers) or standard text options
                if isinstance(options[selected_index], int):  # If it's a number, treat it as a dictionary key
                    selected_action = str(options[selected_index])
                else:  # Standard text option
                    selected_action = options[selected_index]

                # Reset navigation state after selection
                c.using_keyboard_nav = False
                c.selected_option = 0

    # Update the display only in the area where the menu options are drawn
    pygame.display.update(option_rects)

    # Return the selected action (could be a dictionary key or text-based action)
    return selected_action


def end_menu(victory: bool, hero: Hero, combat: CombatSystem):
    """
    Displays the end menu after a combat encounter, allowing the player to either restart or exit based on the victory status.
    The menu responds to mouse and keyboard inputs for navigation.

    :param victory: Boolean indicating if the player won the combat (True) or lost (False).
    :param hero: The Hero object, representing the player's character.
    :param combat: The CombatSystem object, representing the current combat session.
    :return: A string indicating the selected action ('restart' or 'exit').
    """
    c.selected_option = 0  # Reset the selected option to the first one
    c.option_alpha = [0] * len(c.pause_options)  # Reset option transparency

    while True:
        mouse_x, mouse_y = pygame.mouse.get_pos()  # Get mouse position for hover effect
        option_rects = d.draw_ending(victory, c.selected_option)  # Draw the ending menu

        # Handle hover logic: check which option the mouse is hovering over
        hovered_option = None
        for i, rect in enumerate(option_rects):
            if rect.collidepoint(mouse_x, mouse_y):
                hovered_option = i
                break

        # Update selected option if hovering with the mouse (only if not using keyboard navigation)
        if not c.using_keyboard_nav and hovered_option is not None:
            c.selected_option = hovered_option

        # Event handling
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()  # Quit the game if the window is closed
                sys.exit()

            elif event.type == KEYDOWN:
                if event.key == K_UP:
                    c.selected_option = (c.selected_option - 1) % 2  # Navigate up through options (wrap around)
                elif event.key == K_DOWN:
                    c.selected_option = (c.selected_option + 1) % 2  # Navigate down through options (wrap around)
                elif event.key == K_RETURN:
                    # If 'Enter' is pressed, return action based on selected option
                    if c.selected_option == 0:
                        return 'restart'  # Restart the game
                    elif c.selected_option == 1:
                        pygame.quit()  # Quit the game
                        sys.exit()

            # Handle mouse click: check if the user clicks on an option
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  # Left mouse button
                mouse_pos = pygame.mouse.get_pos()  # Get mouse position
                for i, option_rect in enumerate(option_rects):
                    if option_rect.collidepoint(mouse_pos):  # Check if mouse is over the option
                        if i == 0:
                            return 'restart'  # Restart the game
                        elif i == 1:
                            pygame.quit()  # Quit the game
                            sys.exit()

        # Update the display only when necessary (to optimize performance)
        pygame.display.update()
        c.FPSCLOCK.tick(c.FPS)  # Limit the frame rate
