# constant.py
# author: Teresa Madeline and Paula Rios Gomez

import pygame

pygame.init()

# Constant
FPS = 60 # frames per second, the general speed of the program
WINDOWWIDTH = 800 # size of window's width in pixels
WINDOWHEIGHT = 600 # size of windows' height in pixels

FPSCLOCK = pygame.time.Clock()
DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))

KEY_REPEAT_DELAY = 200  # ms before first repeat
KEY_REPEAT_INTERVAL = 100  # ms between repeats

# Global Variables
selected_option = 0  # Tracks the selected menu option
option_alpha = 0
menu_options = ["Start Game", "Quit"]  # Menu options
pause_options = ["Continue", "Options", "Quit to Main Menu"]
combat_options = ["Attack", "Dictionary", "Re roll", "Surrender"]
ending_options = ["Try Again", "Quit"]
shop_option = ["Heal", "Re roll", "Dictionary slot", "Leave"]
dict_option = ["View", "Add word", "Exit"]
title = "Count and Conquer"
using_keyboard_nav = False
speed = 5 # speed of text generation

# List of colors
BLACK= (0, 0, 0, 255)
BLUE= (0, 0, 255, 255)
CYAN= (0, 255, 255, 255)
GOLD= (255, 215, 0, 255)
GRAY= (190, 190, 190, 255)
GREEN= (0, 255, 0, 255)
ORANGE= (255, 165, 0, 255)
PURPLE= (160, 32, 240, 255)
RED= (255, 0, 0, 255)
VIOLET= (238, 130, 238, 255)
YELLOW= (255, 255, 0, 255)
WHITE= (255, 255, 255, 255)

# Fonts
fontObj = pygame.font.Font('Assets/Fonts/GameOfThrones.ttf', 48) # Title font
subFont = pygame.font.Font('Assets/Fonts/GameOfThrones.ttf', 12) # Sub font
menuFont = pygame.font.Font('Assets/Fonts/GameOfThrones.ttf', 18) # Menu font
textFont = pygame.font.Font('Assets/Fonts/AndaleMono.ttf', 18)  # In game font

# numbers
base = {
    1: "at",
    2: "akat",
    3: "sen",
    4: "tor",
    5: "mek",
    6: "zhinda",
    7: "fekh",
    8: "ori",
    9: "qazat"
}

# hundreds = base + ken
hundreds = {100: "ken"}  # Special case for 100
hundreds.update({n * 100: base[n] + "ken" for n in range(2, 10)})  # Generate 200-900

# thousands = base + dalen
thousands = {1000: "dalen"} # Special case for 1000
thousands.update({n * 1000: base[n] + " dalen" for n in range(2, 10)}) # Generate 2000-9000

# Combined number dictionary
number_map = {**hundreds, **thousands}

# Enemies

# https://www.pngegg.com/en/png-nlgbv barbarian
# https://www.pngegg.com/en/png-bnivm wight
# https://www.pngegg.com/en/png-kllou white walker
# https://www.stickpng.com/img/games/elden-ring/elden-ring-bandit bandit
enemies = {"White Walker": "Assets/Images/whitewalker.png",
           "Bandit": "Assets/Images/bandit.png",
           "Wildling": "Assets/Images/wildling.png",
           "Wight": "Assets/Images/wight.png"}

# https://www.pngegg.com/en/png-brovo direwolf
# https://www.pngegg.com/en/png-btawp dragon
# https://www.pinterest.com/pin/game-of-thrones-night-king-sixth-figure--215046950944164401/ night king
bosses = {"Night King": "Assets/Images/nightking.png",
          "Dragon": "Assets/Images/dragon.png",
          "Direwolf": "Assets/Images/direwolf.png"}