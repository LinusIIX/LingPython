# shop.py
# author: Teresa Madeline and Paula Rios Gomez

import pygame
import constant as c
import draw as d
import animation as a
from hero import Hero


def shop(hero: Hero, combat):
    """
    Displays the shop menu where the player can purchase items or leave.
    The shop offers a selection of items to the player, such as healing potions,
    re-rolls, and dictionary slots. The player can interact with the shop by selecting
    different actions that either deduct coins or allow them to leave the shop.
    :param hero: The Hero object, representing the player's character with attributes
                 such as health points, coin count, and inventory.
    :param combat: The CombatSystem object, representing the current combat session
                   (used to resume the combat loop).
    :return: A combat loop function (if the player decides to leave the shop).
    """
    # Load and scale the shop background image
    # https://www.artstation.com/artwork/nQ05E
    background_image = pygame.image.load('Assets/Images/shop.jpg')  # Path to background image
    background_image = pygame.transform.scale(background_image, (c.WINDOWWIDTH, c.WINDOWHEIGHT))  # Scale to fit screen

    # Initialize option alpha transparency for menu options
    c.option_alpha = [0] * len(c.shop_option)

    # Set up the initial shop message
    text: list[str] = []
    text.append("You stumble upon a small shop.\n"
                "It seems that it offers some nifty trinkets.\n"
                "What would you like to do?")

    # Time-related variables for animations
    time = 0
    growing = True  # Flag to indicate if animation is in growing phase
    shrink_timer = 0  # Timer to control shrink effect
    heart_x = c.WINDOWWIDTH // 2 - (c.WINDOWWIDTH // 2 - 160)
    heart_y = (c.WINDOWHEIGHT - len(c.shop_option) * 50) // 2 - 60
    coin_x = heart_x - 20
    coin_y = heart_y + 40

    # Initialize the text display logic
    message_index = 0
    letter = 0
    box_surface, box_rect = d.draw_text_box()  # Draw the text box UI element
    text_rect = d.draw_text_rect(text, box_rect)  # Calculate text box boundaries
    text_waiting_for_input = False  # Flag to track if player input is awaited

    # Main game loop for the shop menu
    while True:
        c.DISPLAYSURF.blit(background_image, (0, 0))  # Display the background image

        # Draw hero character animation in the shop
        a.hero_animation("shop", time, c.WINDOWWIDTH // 2 + 140, c.WINDOWHEIGHT + 400)

        # Draw the text box UI element
        c.DISPLAYSURF.blit(box_surface, box_rect)
        time += 0.1  # Increment time for animations

        # Display the text gradually (letter-by-letter effect)
        if message_index < len(text):
            partial_text = text[message_index][:letter]  # Show part of the current message
            d.draw_multiline_text(partial_text, c.textFont, c.DISPLAYSURF, text_rect[0], 18)

            # Increment letter count until full message is shown
            if letter < len(text[message_index]):
                letter += 1
            else:
                text_waiting_for_input = True  # Wait for player's input after message is displayed

        # If the text is fully displayed, wait for user interaction (input or selection)
        if text_waiting_for_input:
            # Draw the shop title
            title_surface = c.fontObj.render("Shop", True, c.WHITE)
            title_rect = title_surface.get_rect(center=(c.WINDOWWIDTH // 2, 100))
            c.DISPLAYSURF.blit(title_surface, title_rect)

            # Perform heart and coin animations while waiting for player input
            heart_done = a.heart_animation(hero.hp, time, x=heart_x, y=heart_y, growing=growing,
                                           shrink_timer=shrink_timer)
            coin_done = a.coin_animation(time, x=coin_x, y=coin_y, growing=growing, shrink_timer=shrink_timer,
                                         num_coin=hero.coin)
            shrink_timer += 2  # Increment shrink timer to control the pulsing effect

            # When heart and coin animations are done, switch to pulsing effect
            if heart_done and coin_done:
                growing = False  # Switch animation to pulsing mode

            # Show the shop menu for item selection
            from menu import shop_menu
            action = shop_menu()  # Get the selected action from the shop menu

            if action:
                selected_action = action
                # print(f"Action selected: {selected_action}")

                # Handle the action based on player's choice
                if selected_action == 'Heal':
                    if hero.hp < 3 and hero.coin >= 10:
                        hero.increment_hp()  # Heal the player
                        text.append("You bought a potion.\n"
                                    "You recovered 1 hp.\n"
                                    "Anything else you would like to do?")
                        hero.buy_item(10)  # Deduct 10 coins
                    elif hero.hp >= 3:
                        text.append("You are already at full health.\n"
                                    "Anything else you would like to do?")
                    else:
                        text.append(f"You don't have enough coins.")

                elif selected_action == 'Re roll':
                    if hero.coin >= 20:
                        hero.buy_reroll()  # Allow the player to purchase a re-roll
                        text.append(f"You bought a re-roll!\n"
                                    f"Your current re-roll is {hero.reroll}.\n"
                                    f"Anything else you would like to do?")
                        hero.buy_item(20)  # Deduct 20 coins
                    else:
                        text.append(f"You don't have enough coins.")

                elif selected_action == 'Dictionary slot':
                    if hero.coin >= 30:
                        hero.increment_max_dict_size()  # Expand the dictionary size
                        hero.buy_item(30)  # Deduct 30 coins
                        text.append(f"You bought an additional slot for your dictionary!\n"
                                    f"You can now hold {hero.max_dictionary_size} words.\n"
                                    f"Anything else you would like to do?")
                    else:
                        text.append(f"You don't have enough coins.")

                elif selected_action == 'Leave':
                    # If the player chooses to leave, return to the combat loop
                    from main import combat_loop
                    return combat_loop

                # Update message to reflect the new information
                message_index = len(text) - 1  # Set message index to the last entry
                letter = 0  # Start revealing the new message from the beginning
                text_waiting_for_input = False  # Allow new text to animate

        # Update the display each frame
        pygame.display.update()
        c.FPSCLOCK.tick(c.FPS)  # Ensure the game runs at a consistent frame rate