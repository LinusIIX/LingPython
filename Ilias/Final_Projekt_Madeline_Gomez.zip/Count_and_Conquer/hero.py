# hero.py
# author: Teresa Madeline

from collections.abc import Callable
import pygame
from constant import base
import constant as c
import draw as d

# Hero stat
class Hero:
    def __init__(self):
        # Initialize hero attributes
        self.hp: int = 3  # Hero health points
        self.coin: int = 0  # Hero coin count
        self.dictionary: dict[int, str] = {}  # Dictionary storing base words
        self.max_dictionary_size: int = 3  # Maximum number of words in dictionary
        self.reroll: int = 3  # Number of rerolls available
        self.seen_bases: list[int] = [1]  # Bases encountered by the hero
        self.in_combat: bool = False  # Combat state flag

    def increase_coin(self, coins: int = 5)-> None:
        """
        Increase hero's coins by a given amount.
        :param coins: amount of coins increased (default is 5)
        :return:
        """
        self.coin += coins

    def buy_item(self, coins:int)-> None:
        """
        Decrease hero's coins by a given amount.
        :param coins: amount of coins spent.
        :return:
        """
        self.coin -= coins

    def increment_hp(self)-> None:
        """
        Increase hero's hp by one.'
        :return:
        """
        self.hp += 1

    def take_damage(self)-> bool:
        """
        Decrease hero's hp by one.
        :return:
        """
        self.hp -= 1  # Reduce health
        if self.hp <= 0:
            # print("You have been defeated! Game over.")
            return True
        else:
            # print(f"Wrong! Try again. Hp: {self.hp}")
            return False

    def open_dictionary(self, new_base: int, combat)-> Callable:
        """
        Open the dictionary menu for the hero, allowing interaction with dictionary menu.
        Handles word addition, replacement, and viewing.
        :param new_base: the new base of the number to add
        :param combat: combat class instance
        :return: to combat_loop function
        """
        # Load the background image for the dictionary menu
        # https://www.vectorstock.com/royalty-free-vector/old-paper-textured-blank-background-vector-54494294
        background_image = pygame.image.load('Assets/Images/dictionary.jpg')
        background_image = pygame.transform.scale(background_image, (c.WINDOWWIDTH, c.WINDOWHEIGHT))

        # Initialize transparency for the menu options
        c.option_alpha = [0] * len(c.dict_option)

        # Initial message (poem) displayed in the dictionary menu
        text = [
            "A thousand strong, a force unnamed — dalen.\n"
            "A hundred lesser, yet still it stands — ken.\n"
            "A quiet force, that shapes the whole — ma,\n"
            "Binding the parts to make them whole."
        ]
        notif = []  # Notifications to display
        state = "main"  # Menu state (main menu, replace choice, etc.)
        time = 0  # Timer for animations
        message_index = 0  # Index for the current message being shown
        letter = 0  # Number of letters to be shown in the current message

        # Create an empty surface for the text box (UI element)
        box_surface = pygame.Surface((400, 100), pygame.SRCALPHA)
        box_surface.set_alpha(0)  # Set transparency to fully transparent
        box_surface.fill((0, 0, 0, 0))  # Fill the surface with black (transparent)

        # Position the rectangle (center of the screen)
        box_rect = box_surface.get_rect(center=(c.WINDOWWIDTH // 2, c.WINDOWHEIGHT // 2 - 200))

        # Draw the rectangle for text display
        text_rect = d.draw_text_rect(text, box_rect)
        text_waiting_for_input = False  # Flag to determine if the program is waiting for input

        # Timer to manage the duration of notifications
        start = pygame.time.get_ticks()

        while True:
            # Display background and UI elements
            c.DISPLAYSURF.blit(background_image, (0, 0))
            d.draw_pause_button()

            # Draw main content box
            c.DISPLAYSURF.blit(box_surface, box_rect)
            time += 0.1  # Increment time for animations

            # Display notifications for a brief period (2000 ms)
            if notif and pygame.time.get_ticks() - start < 2000:
                notif_surface = pygame.Surface((c.WINDOWWIDTH, 50), pygame.SRCALPHA)
                notif_surface.fill((0, 0, 0, 180))  # Semi-transparent black background
                c.DISPLAYSURF.blit(notif_surface, (0, c.WINDOWHEIGHT // 2 - 70))
                d.draw_text(notif[0], c.textFont, c.DISPLAYSURF, (c.WINDOWWIDTH // 2, c.WINDOWHEIGHT // 2 - 45),
                            color=c.WHITE)
            else:
                start = pygame.time.get_ticks()  # Reset the start time for the next notification
                if notif:
                    notif.pop(0)  # Remove the notification after the duration

            # Text animation logic: Gradually display the text one letter at a time
            if message_index < len(text):
                partial_text = text[message_index][:letter]  # Show part of the current message
                d.draw_multiline_text(partial_text, c.textFont, c.DISPLAYSURF, text_rect[0], 18, color=c.BLACK)

                if letter < len(text[message_index]):
                    letter += 1  # Increment letter count for the animation effect
                else:
                    # Once the message is fully displayed, move to the next message
                    if message_index < len(text) - 1:
                        message_index += 1
                        letter = 0
                    else:
                        text_waiting_for_input = True  # Wait for player input once all messages are shown

            if text_waiting_for_input:
                from menu import dict_menu  # Import the dictionary menu options function

                # Get action based on the current state (main, replace, view, etc.)
                if state == "main":
                    action = dict_menu()
                elif state == "replace_choice":
                    action = dict_menu(show_replace=True)
                elif state == "viewing":
                    action = dict_menu(show_back=True)
                elif state == "replace_selection":
                    action = dict_menu(hero=self)  # Show dictionary entries

                if action:
                    if state == "main":
                        if action == 'View':
                            content = "Dictionary Contents:\n"
                            if self.dictionary:
                                content += "\n".join([f"{k}. {v}" for k, v in self.dictionary.items()])
                            else:
                                content += "Your dictionary is empty."
                            text = [content]  # Display dictionary contents
                            state = "viewing"
                            message_index = 0
                            letter = 0
                            text_waiting_for_input = False

                        elif action == 'Add word':
                            # Prevent adding words during boss fights or if word already exists
                            if new_base == 0:
                                notif.append("You can't add words during a boss fight!")
                            elif new_base in self.dictionary:
                                notif.append("Word already in dictionary!")
                            else:
                                if self.is_dict_max():  # If dictionary is full, ask for replacement
                                    text = ["Your dictionary is full! Replace existing word?"]
                                    state = "replace_choice"
                                    message_index = 0
                                    letter = 0
                                    text_waiting_for_input = False
                                else:
                                    if self.add_to_dict(new_base):  # Add the word to the dictionary
                                        notif.append(f"Added '{self.dictionary[new_base]}' to dictionary!")
                                    else:
                                        notif.append("Failed to add word")
                                    state = "main"

                        elif action == 'Exit':
                            # Exit the dictionary and return to the combat loop
                            combat.menu_active = False  # Reset the menu state
                            from main import combat_loop
                            return combat_loop

                    elif state == "replace_choice":
                        if action == 'Yes':
                            text = ["Select word to replace:"]
                            state = "replace_selection"
                            message_index = 0
                            letter = 0
                            text_waiting_for_input = False
                        else:
                            state = "main"
                            text = ["Operation cancelled"]
                            message_index = 0
                            letter = 0
                            text_waiting_for_input = False

                    elif state == "replace_selection":
                        try:
                            choice = int(action)
                            if choice in self.dictionary:
                                old_word = self.dictionary[choice]
                                self.replace_dict(new_base, choice)  # Replace the old word with new base word
                                notif.append(f"Replaced {old_word} with {self.dictionary[new_base]}")
                                state = "main"
                            else:
                                notif.append("Invalid selection")
                        except ValueError:
                            notif.append("Please select a number")

                    elif state == "viewing" and action == 'Back':
                        state = "main"
                        notif.append("Returning to dictionary menu...")

                        # Reset the text to the original poem
                        text = [
                            "A thousand strong, a force unnamed — dalen.\n"
                            "A hundred lesser, yet still it stands — ken.\n"
                            "A quiet force, that shapes the whole — ma,\n"
                            "Binding the parts to make them whole."
                        ]
                        message_index = 0  # Reset message index for re-animation
                        letter = 0  # Reset letter index for new animation
                        text_waiting_for_input = False

                    # Reset text animation state after each action
                    message_index = 0
                    letter = 0
                    text_waiting_for_input = False

            # Update display with new frame
            pygame.display.update()
            c.FPSCLOCK.tick(c.FPS)  # Maintain consistent frame rate

    def increment_max_dict_size(self)-> None:
        """
        Increase the max dictionary size by 1.
        :return:
        """
        self.max_dictionary_size += 1

    def is_dict_max(self)->bool:
        """
        Check if the dictionary is full.
        :return:
        """
        return self.dictionary.__len__() >= self.max_dictionary_size

    def do_reroll(self)-> bool:
        """
        Perform a re-roll, decreasing the re-roll amount by 1 if successful.
        :return:
        """
        if self.reroll > 0:
            self.reroll -= 1
            return True
        return False

    def buy_reroll(self)-> None:
        """
        Increase the re-roll amount by 1.
        :return:
        """
        self.reroll += 1

    def add_to_dict(self, base_number:int)-> bool:
        """
        Add a new word to the dictionary.
        :param base_number: base of the number to be added.
        :return: successful?
        """
        if base_number != 1 and base_number not in self.dictionary.keys(): # if base is not 1 and no dupes exist
            self.dictionary[base_number] = base.get(base_number)
            return True
        return False

    def dict_str(self)->str:
        return str(self.dictionary)

    def replace_dict(self, new_base:int, old_base:int)-> None: #
        """
        Replace the word in dictionary with the new one.
        :param new_base: new number
        :param old_base: old number
        :return:
        """
        self.dictionary.pop(old_base) # remove old entry
        self.dictionary[new_base] = base.get(new_base) # add new entry

    def add_base_to_list(self, base_number:int)-> None:
        """
        Add a new base word to the seen list.
        :param base_number: number to add
        :return:
        """
        if base_number != 0 and base_number not in self.seen_bases:
            self.seen_bases.append(base_number)
