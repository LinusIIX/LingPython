# main.py
# author: Teresa Madeline and Paula Rios Gomez

from collections.abc import Callable
import constant as c
import menu as m
import draw as d
import animation as a
import eventHandler as e
import pygame, sys
from hero import Hero
from combat import CombatSystem

def start_game():
    """
    Initializes the Pygame environment and sets up the game window.
    This function initializes Pygame, which is required for handling graphics,
    events, and game logic. It also sets the window title to 'Final Projekt'.
    :return:
    """
    pygame.init()
    pygame.display.set_caption('Final Projekt')


def title_screen():
    """
    Displays the title screen before transitioning to the main menu.
    The title appears in the center of the screen and gradually moves upwards.
    Below it, the developer credits are shown and fade out over time.
    The transition completes when the title moves past a certain point or
    the user presses Enter to skip the animation.
    Events:
        - QUIT: Exits the game if the user closes the window.
        - KEYDOWN (Enter): Skips the title screen and transitions immediately.

    :return: None
    """
    # Displays the c.title screen before transitioning to the main menu
    c.DISPLAYSURF.fill(c.BLACK)  # Clear the screen with black

    # Draw the c.title
    title_surface = c.fontObj.render(c.title, True, c.WHITE)
    title_rect = title_surface.get_rect(center=(c.WINDOWWIDTH // 2, c.WINDOWHEIGHT // 2))

    # Draw subscript
    sub_surface = c.subFont.render("By Paula Rios Gomez and Teresa Madeline", True, c.WHITE)
    sub_rect = sub_surface.get_rect(center=(c.WINDOWWIDTH // 2, c.WINDOWHEIGHT // 2 + 40))

    # Fade-out effect for developer name (alpha decrease over time)
    sub_alpha = 255  # Fully opaque at first

    # Title movement effect (moving upwards)
    title_y_pos = c.WINDOWHEIGHT // 2 # Initial vertical position of the c.title
    title_move_speed = 3  # How fast the c.title moves upwards
    sub_fade_speed = 5  # Speed of fading the developer's name

    # Draw the screen
    c.DISPLAYSURF.blit(title_surface, title_rect)
    c.DISPLAYSURF.blit(sub_surface, sub_rect)
    pygame.display.update()

    start_time = pygame.time.get_ticks()
    transition_started = False  # Track transition state
    sub_faded = False  # Track if subscript has fully faded

    # Transition loop
    while True:
        elapsed_time = pygame.time.get_ticks() - start_time  # Time passed since c.title screen appeared

        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                # Allow skipping the c.title screen with Enter key
                return

        # Wait for 1 second before starting the transition
        if elapsed_time > 1000 and not transition_started:
            transition_started = True  # Start the transition

        if transition_started:
            # Fade out the subscript
            if not sub_faded:
                sub_alpha -= sub_fade_speed  # Fade out the subscript
                if sub_alpha < 0:  # Ensure the subscript doesn't go below 0
                    sub_alpha = 0
                    sub_faded = True  # Mark that the subscript is fully faded

            # Move the c.title upwards
            if sub_faded:  # Only start moving the c.title after the subscript has faded
                title_y_pos -= title_move_speed  # Move the c.title upwards

            # Re-render the screen with updated c.title and subscript
            c.DISPLAYSURF.fill(c.BLACK)  # Clear the screen again
            title_rect = title_surface.get_rect(center=(c.WINDOWWIDTH // 2, title_y_pos))  # Update c.title position
            sub_surface.set_alpha(sub_alpha)  # Apply alpha transparency to the subscript

            # Draw the c.title and subscript again
            c.DISPLAYSURF.blit(title_surface, title_rect)
            c.DISPLAYSURF.blit(sub_surface, sub_rect)

            pygame.display.update()  # Update the display

        # Stop the transition after the subscript is fully faded and c.title is moved off-screen
        if sub_alpha <= 0 and title_y_pos <= 100:
            break

        # Control the game loop speed
        c.FPSCLOCK.tick(c.FPS)


def hero_intro(hero: Hero, combat: CombatSystem):
    """
    Displays the hero introduction scene with animated text and character animation.
    The scene introduces the hero's backstory and sets up the main narrative.
    A text box appears with a typewriter effect to reveal the story gradually.
    The hero's animation is displayed on the screen.
    The player can:
    - Pause the game (which saves the current state).
    - Exit to the main menu or proceed to the next scene.
    :param hero: The hero character whose story is being introduced.
    :param combat: The combat system instance to manage interactions.
    :return: Function reference to the next scene or action.
    """
    # Clear the screen with a white background
    c.DISPLAYSURF.fill(c.WHITE)
    pygame.display.update()

    # Create a text box for displaying dialogue
    box_surface, box_rect = d.draw_text_box()

    # Story text displayed in the introduction
    text: list[str] = [
        "This is you. Previously in your adventure\n"
        "you have encountered a mysterious unknown language.\n"
        "You seek to uncover more of this language."
    ]

    n = 0  # Letter index for typewriter effect
    i = 0  # Line index for multiline text

    # Get text positioning
    text_rect = d.draw_text_rect(text, box_rect)

    time: float = 0  # Timer for animation control

    # Game loop for the hero introduction scene
    while True:
        # Handle player inputs and events
        i, n, function, state = e.event_handler(i, n, text, m.main_menu, prologue, hero_intro)

        if state == "pause":  # If the game is paused
            result = function  # Store the result (pause menu navigation)
            if result == prologue:  # If the user resumes the game
                pygame.event.clear()  # Clear any lingering events
                continue  # Resume from where it left off
            else:
                return result  # Return to main menu or quit

        if function:
            return function  # Transition to the next scene (e.g., main menu or prologue)

        time += 0.1  # Increment animation time

        # Redraw screen background
        c.DISPLAYSURF.fill(c.WHITE)

        # Draw the pause button
        d.draw_pause_button()

        # Animate the hero sprite (standing animation facing forward)
        a.hero_animation("front", time, c.WINDOWWIDTH // 2)

        # Display the text box
        c.DISPLAYSURF.blit(box_surface, box_rect)

        # Render text with typewriter effect
        partial_text = text[i][:n]  # Reveal text character by character
        d.draw_multiline_text(partial_text, c.textFont, c.DISPLAYSURF, text_rect[i], 18)

        n += 1  # Move to the next character
        pygame.time.wait(c.speed)  # Control text display speed

        # Update the screen
        pygame.display.flip()
        c.FPSCLOCK.tick(c.FPS)


def prologue(hero: Hero, combat: CombatSystem):
    """
    Displays the prologue scene with background visuals, animated text, and effects.
    This scene introduces the player's journey deeper into the mountain, where they uncover
    mysterious inscriptions and a strange book written in an unknown language. The text
    appears with a typewriter effect, accompanied by animations such as a pulsing heart
    and a spinning coin.
    :param hero: The main character object.
    :param combat: The combat system to handle future battles.
    :return: Function reference for transitioning to the next scene.
    """
    # Load and scale the background image (medieval fantasy setting)
    # Image source: https://stablediffusionweb.com/image/21439472-medieval-dark-fantasy-background
    background_image = pygame.image.load('Assets/Images/Background.jpg')
    background_image = pygame.transform.scale(background_image, (c.WINDOWWIDTH, c.WINDOWHEIGHT))

    # Load and position the book image (appears later in the scene)
    # Image source: https://www.pngegg.com/en/png-wrqgt
    book_image = pygame.image.load('Assets/Images/old-book.png')
    book_image_rect = book_image.get_rect(center=(c.WINDOWWIDTH // 2, c.WINDOWHEIGHT // 2))

    # Create a text box for displaying the narrative
    box_surface, box_rect = d.draw_text_box()

    # Story text displayed progressively
    text: list[str] = [
        "Deep within the mountain,\nyou find a series of markings on the ground,\nmuch like ancient numerals.",
        "You crouch down to examine them closer\nand realize that they might be numbers\nin the same unknown language.",
        "As you look around, you find an old leather book,\nlying on the ground.",
        "You open the bounded leather,\nand upon its yellowed pages, faded with time,\nwhispers of knowledge in ink still shine.",
        "\"A thousand strong, a force unnamed — dalen.\nA hundred lesser, yet still it stands — ken.\n"
        "A quiet force, that shapes the whole — ma,\nBinding the parts to make them whole.\"",
        "[You have obtained a mysterious book.\nItem added to inventory.]",
        "You continue on deep into the mountain...",
        "You feel a sudden shift in the air,\na heavy presence creeping closer,\nand the hairs on your neck stand on end.",
        "Something is approaching, something unseen,\nyet its threat is undeniable.",
        "Your heart races,\nand you instinctively grip the book tighter,\npreparing for whatever danger lies ahead."
    ]

    n = 0  # Tracks the number of letters displayed (typewriter effect)
    i = 0  # Tracks the current line being displayed

    # Generate text positioning inside the box
    text_rect = d.draw_text_rect(text, box_rect)

    time: float = 0  # Timer for animation control
    growing = True  # Controls the heart animation growth
    shrink_timer = 0  # Timer for shrink phase
    heart_x = c.WINDOWWIDTH // 2  # Heart animation position (centered at top)
    heart_y = 50

    # Start the text generation and animations together
    while i < len(text):
        # Handle player input (e.g., skipping, pausing, transitioning scenes)
        i, n, function, state = e.event_handler(i, n, text, hero_intro, combat_loop, prologue)

        if state == "pause":  # If the game is paused
            result = function  # Store the function reference for resuming
            if result == prologue:  # If resuming, clear event queue
                pygame.event.clear()
                continue  # Resume from where it left off
            else:
                return result  # Handle quitting or returning to the main menu

        if function:
            return function  # Move to the next scene

        # Draw the background image
        c.DISPLAYSURF.blit(background_image, (0, 0))

        # Draw the pause button
        d.draw_pause_button()

        # Update time for animations
        time += 0.1

        # Animate the hero's heartbeat effect (pulsing when danger is near)
        heart_done = a.heart_animation(hero.hp, time, x=heart_x, y=heart_y, growing=growing, shrink_timer=shrink_timer)

        # Animate a coin spinning effect
        coin_done = a.coin_animation(time, growing=growing, shrink_timer=shrink_timer)

        shrink_timer += 2  # Gradually decrease the pulse effect

        if heart_done and coin_done:  # If animations finish the growth phase
            growing = False  # Enter pulsing phase

        # Display the text box
        c.DISPLAYSURF.blit(box_surface, box_rect)

        # Render the text line by line, character by character
        partial_text = text[i][:n]  # Reveal text incrementally
        d.draw_multiline_text(partial_text, c.textFont, c.DISPLAYSURF, text_rect[i], 18)

        # Display the book image after the second line and before the fifth line
        if 2 < i < 5:
            c.DISPLAYSURF.blit(book_image, book_image_rect)

        # Increment letter count for the typewriter effect
        n += 1
        pygame.time.wait(c.speed)  # Control text speed

        # Refresh the display
        pygame.display.flip()
        c.FPSCLOCK.tick(c.FPS)

def combat_loop(hero: Hero, combat: CombatSystem):
    """
    Handles the main combat loop, including enemy encounters, input handling,
    and transitioning between different combat phases.
    :param hero: The player's character, which stores stats and inventory.
    :param combat: The combat system managing enemies, attacks, and battle mechanics.
    :return: Function reference for transitioning out of combat (e.g., to shop or end screen).
    """

    # Display hero's current HP and coin count (debugging purposes)
    # print(hero.hp)
    # print(hero.coin)

    # Initialize combat variables
    c.selected_option = 0  # Default to first menu option
    combat.input_active = False  # Whether the player is entering text input
    combat.menu_active = False  # Whether the combat menu is open
    c.option_alpha = [0] * len(c.combat_options)  # Initialize transparency values for menu options

    time = 0.0  # Animation timer
    entry_time = 0.0  # Controls slide-in animation duration

    n = 0  # Tracks number of letters displayed in text
    i = 0  # Tracks current text line

    c.using_keyboard_nav = False  # Flag for keyboard navigation mode

    # Enable key repeat for continuous navigation
    pygame.key.set_repeat(c.KEY_REPEAT_DELAY, c.KEY_REPEAT_INTERVAL)

    # List of text messages displayed during combat (currently empty)
    text: list[(str)] = []

    # Draw the text box for messages
    box_surface, box_rect = d.draw_text_box()
    text_rect = d.draw_text_rect(text, box_rect)

    while True:
        # Handle player input events
        event_info = e.handle_events(context='combat', input_active=combat.input_active)

        # Manage slide-in animation duration
        if entry_time < 600:
            entry_time += 80

        # Draw combat UI elements
        combat.draw(c.DISPLAYSURF, time, entry_time, n, i)

        # Handle player input when actively entering commands
        if combat.input_active:
            result = combat.handle_input(event_info)

            # Draw the player's input text
            d.draw_text_input(c.DISPLAYSURF, combat.input_text)

            if isinstance(result, list):  # If combat ends
                # print("end")
                return m.end_menu(result[1], Hero(), CombatSystem(Hero()))  # Transition to end menu
            elif result == "shop":  # Transition to shop
                # print("shop")
                n, i = 0, 0
                combat.pending_shop_transition = True
            elif result == "fight":  # Combat continues
                # print("fight")
                # print(combat.current_enemy.name)
                combat.victory_time = pygame.time.get_ticks()
                n, i = 0, 0
            elif result == "wrong":  # Incorrect input response
                combat.error_start_time = pygame.time.get_ticks()  # Track error message time
                # print("wrong")
                n, i = 0, 1  # Reset text animation to show error message

        else:
            # Handle navigation and selection in the combat menu
            if event_info['action'] == 'navigate':
                # Update the selected option based on input direction
                current_selection = c.selected_option if c.selected_option is not None else 0
                new_selection = max(0, min(len(c.combat_options) - 1,
                                           current_selection + (-1 if event_info['direction'] == 'up' else 1)))
                c.selected_option = new_selection
            elif event_info['action'] == 'select':
                option = event_info.get('option')
                if option is not None and 0 <= option < len(c.combat_options):
                    if c.combat_options[option] == 'attack':
                        combat.input_active = True  # Enable input mode for attack

            elif event_info['action'] == 'back':  # Exit input mode
                combat.input_active = False

        # Remove error message after a delay (3 seconds)
        if hasattr(combat, 'error_start_time') and combat.error_start_time is not None:
            if pygame.time.get_ticks() - combat.error_start_time >= 3000:
                i, n = 0, 0  # Reset text animation
                del combat.error_start_time  # Remove error timer

        # Handle victory transition (wait 3 seconds before spawning next enemy)
        if combat.victory and (pygame.time.get_ticks() - combat.victory_time >= 3000):
            n, i, entry_time = 0, 0, 0  # Reset text and animation
            combat.victory = False  # Reset victory flag

            # If transitioning to shop, handle it before spawning new enemy
            if combat.pending_shop_transition:
                combat.spawn_enemy()  # Prepare new enemy
                combat.pending_shop_transition = False
                from shop import shop
                return shop
            else:
                combat.spawn_enemy()  # Spawn new enemy normally

        # Process combat menu actions
        if combat.menu_active and not combat.input_active:
            action = m.combat_menu()
            if action:
                # print(f"Action selected: {action}")
                if action == 'attack':
                    combat.input_active = True
                    combat.menu_active = False
                elif action == 'pause':  # Pause game
                    return m.pause_menu(combat_loop)
                elif action == 'dictionary':  # Open enemy dictionary
                    hero.open_dictionary(combat.current_enemy.base, combat)
                    combat.menu_active = False  # Close menu
                elif action == 'reroll':  # Use a re-roll if available
                    if combat.current_enemy.type == "normal" and hero.do_reroll():
                        text.append(f"You have {hero.reroll} re-roll(s) left.")
                        combat.waves -= 1
                        entry_time = 0
                        combat.spawn_enemy()
                    else:
                        text.append("You have run out of re-rolls!")
                elif action == 'surrender':  # End combat and return to main menu
                    # print("surrender")
                    return m.end_menu(False, Hero(), CombatSystem(Hero()))

        # Update game state and animations
        combat.update()
        time += 0.1
        n += 1  # Progress text animation

        # Refresh the display
        pygame.display.flip()
        c.FPSCLOCK.tick(c.FPS)

# Main function to run the game
if __name__ == '__main__':
    start_game()  # Initialize game settings, assets, and configurations
    title_screen()  # Display the title screen

    # Main game loop: Runs indefinitely until the player exits
    while True:
        hero = Hero()  # Create a new hero instance for each session
        combat = CombatSystem(hero)  # Initialize the combat system with the hero

        # Display the main menu and get the next function to execute
        next_function: Callable = m.main_menu(hero, combat)

        # Game loop for handling different game states
        while True:
            next_function = next_function(hero, combat)  # Execute the next function
            # print(next_function)  # Debugging: Print the next function being executed

            # Check if the player chooses to exit the game
            if next_function == sys.exit:
                pygame.quit()  # Quit pygame properly
                sys.exit()  # Terminate the program

            # If the player returns to the main menu or restarts, break out of the loop
            if next_function in (m.main_menu, 'restart'):
                break  # Exit inner loop, reinitialize hero and combat in the outer loop