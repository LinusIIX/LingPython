# this project was made by mika di prima, patrick störk and annalena gerweck
# we worked together on it on discord, so everyone pretty much contributed everywhere

# the graphical and sound assets included in this game were custom made in a collaborative effort by all members of the group.

# this project was run by annalena gerweck on linux with python 3.10.12
# the other contributers worked on windows with python 3.11.9

# to interact with the game, the left mouse button can be used to proceed in the dialogue, the keyboard is used to input a solution and the enter key is used to submit the solution.


import os
import random
import pygame as pg
from pygame.locals import *
from assets import GameDataLink


gameData = GameDataLink.get_data()
gameData["neededPoints"] = 0
gameData["text"] = "This game is about learning to use pronouns in the dothraki language."

main_dir = os.path.split(os.path.abspath(__file__))[0]
data_dir = os.path.join(main_dir, "data")

# pygame initialization
pg.mixer.pre_init(44100, -16, 2, 2048)
pg.init()
scaleMult = 10 # this variable serves the purpose of easily adjusting things like screen size etc
width = 128 * scaleMult
height = 72 * scaleMult
screen = pg.display.set_mode((width, height))
clock = pg.time.Clock()
running = True
solution = "I think it is..."
dialogue = ["Unknown word? Look it up.", "Knowledge is power!", "Prepare yourself!", "What is this word?", solution, "That's correct!", "Failure is learning."]
person = 0
case = 0

lanternLocs = [(width/2+200, height/2-33), (width/2+160, height/2-205), (width/2-335, height/2-35), (width/2-310, height/2-215)] # the four locations of the lanterns

# save dialogue information
current_dialogue = 0
dothraki = [("anha", "anna", "anni", "anhaan", "anhoon"),("yer", "yera", "yeri", "yeraan", "yeroon"),("me","mae","mae","maan","moon"),("kisha","kisha","kishi","kishaan","kishoon"),("yeri","yeri","yeri","yerea","yeroa"),("mori","mora","mori","morea","moroa"),("shafka","shafka","shafki","shafkea","shafkoa")]
type1 = ["1st Person Singular","2nd Person Singular","3rd Person Singular","1st Person Plural","2nd Person Plural","3rd Person Plural","2nd Person Formal"]
type2 = ["Nominative","Accusative","Genitive","Allative","Ablative"]
location1 = (0,0)
location2 = (0,0)
t1 = ""
t2 = ""
attackNotDecided = True

# ui elements
enemy = random.randint(1,4) # chooses which enemy is selected
playerHealth = 7
enemyHealth = 4
redLant = 10
initEnemy = True
lanternStatus = [False, False, False, False]
score = 0

soundtrack = pg.mixer.music.load(os.path.join(data_dir, "sound", "soundtrack", "Soundtrack.wav"))

# loading background image
bgImage = pg.transform.scale(pg.image.load(os.path.join(data_dir, "background", "cave.png")), (width, height))

# loading full enemy sprites
warriorFull = pg.transform.scale(pg.image.load(os.path.join(data_dir, "sprites", "full", "warrior.png")), (32*scaleMult, 32*scaleMult))
rogueFull = pg.transform.scale(pg.image.load(os.path.join(data_dir, "sprites", "full", "rogue.png")), (32*scaleMult, 32*scaleMult))
wizardFull = pg.transform.scale(pg.image.load(os.path.join(data_dir, "sprites", "full", "wizard.png")), (32*scaleMult, 32*scaleMult))
paladinFull = pg.transform.scale(pg.image.load(os.path.join(data_dir, "sprites", "full", "paladin.png")), (32*scaleMult, 32*scaleMult))

# loading enemy portraits
warriorPort = pg.transform.scale(pg.image.load(os.path.join(data_dir, "sprites", "portrait", "warriorport.png")), (32*scaleMult, 32*scaleMult))
roguePort = pg.transform.scale(pg.image.load(os.path.join(data_dir, "sprites", "portrait", "rogueport.png")), (32*scaleMult, 32*scaleMult))
wizardPort = pg.transform.scale(pg.image.load(os.path.join(data_dir, "sprites", "portrait", "wizardport.png")), (32*scaleMult, 32*scaleMult))
paladinPort = pg.transform.scale(pg.image.load(os.path.join(data_dir, "sprites", "portrait", "paladinport.png")), (32*scaleMult, 32*scaleMult))

# loading lantern sprites
lanternBlue = pg.transform.scale(pg.image.load(os.path.join(data_dir, "sprites", "full", "lanternblue.png")), (16*scaleMult, 16*scaleMult))
lanternRed = pg.transform.scale(pg.image.load(os.path.join(data_dir, "sprites", "full", "lanternred.png")), (16*scaleMult, 16*scaleMult))

# loading ui elements
mainUI = pg.transform.scale(pg.image.load(os.path.join(data_dir, "ui", "full", "gui.png")), (width, height))
heart = pg.transform.scale(pg.image.load(os.path.join(data_dir, "ui", "icon", "HP.png")), (15*scaleMult, 15*scaleMult))
soul = pg.transform.scale(pg.image.load(os.path.join(data_dir, "ui", "icon", "EnemyHP.png")), (15*scaleMult, 15*scaleMult))

# music
pg.mixer.music.load(os.path.join(data_dir, "sound", "soundtrack", "Soundtrack.wav"))
pg.mixer.music.play(-1)

def ui():
    global solution

    # load the portrait of the current enemy
    if enemy == 1:
        screen.blit(warriorPort, (-4*scaleMult,height - 28*scaleMult))
    elif enemy == 2:
        screen.blit(roguePort, (-4*scaleMult,height - 28*scaleMult))
    elif enemy == 3:
        screen.blit(wizardPort, (-4*scaleMult,height - 28*scaleMult))
    else:
        screen.blit(paladinPort, (-4*scaleMult,height - 28*scaleMult))

    # load player health bar
    startWidth = 32*scaleMult
    startHeight = -1.5*scaleMult

    for i in range(playerHealth): # for each player HP, one heart is added to the screen
        screen.blit(heart, (startWidth,startHeight))
        startWidth += 8*scaleMult

    # load enemy health bar
    for i in range(enemyHealth): # for each enemy HP, one lantern is added in the corner
        if (i < 2):
            screen.blit(soul, (width-(1.6 - (i % 2) * 0.6)*15*scaleMult, height-1.6*15*scaleMult))
        else:
            screen.blit(soul, (width-(1.6 - (i % 2) * 0.6)*15*scaleMult, height-15*scaleMult))


    font = pg.font.Font(None, 64)
    text = font.render(dialogue[current_dialogue], True, (10, 10, 10)) # display the dialogue in the dialogue box
    screen.blit(text, text.get_rect(centerx=width/2, y=height/2+235))

def enemyLoad():
    # load the sprite of the current enemy
    global initEnemy
    global enemyHealth
    global lanternStatus
    global redLant

    # enemy initialization for each possible enemy

    if enemy == 1:
        screen.blit(warriorFull, ((width-32*scaleMult)/2, (height-19*scaleMult)/2))
        if initEnemy == True:
            enemyHealth = random.randint(2,4)
            for y in range(enemyHealth):
                lanternStatus[y] = True
            initEnemy = False
    elif enemy == 2:
        screen.blit(rogueFull, ((width-32*scaleMult)/2, (height-19*scaleMult)/2))
        if initEnemy == True:
            enemyHealth = random.randint(1,3)
            for y in range(enemyHealth):
                lanternStatus[y] = True
            initEnemy = False
    elif enemy == 3:
        screen.blit(wizardFull, ((width-32*scaleMult)/2, (height-19*scaleMult)/2))
        if initEnemy == True:
            enemyHealth = random.randint(1,2)
            for y in range(enemyHealth):
                lanternStatus[y] = True
            initEnemy = False
    else:
        screen.blit(paladinFull, ((width-32*scaleMult)/2, (height-19*scaleMult)/2))
        if initEnemy == True:
            enemyHealth = random.randint(3,4)
            for y in range(enemyHealth):
                lanternStatus[y] = True
            initEnemy = False

    for x in range(4):
        if lanternStatus[x]:
            if redLant == x:
                screen.blit(lanternRed, lanternLocs[x])
            else:
                screen.blit(lanternBlue, lanternLocs[x])

def enemyAttack():
    global redLant
    global t1
    global t2
    global location1
    global location2
    global person
    global case
    print("attackprep")
    person = random.randint(0,6) # random number to select something from the type1 array
    case = random.randint(0,4) # random number to select something from the type2 array
    redLant = random.randint(0,3)

    while lanternStatus[redLant] == False & enemyHealth >= 0:
        redLant = random.randint(0,3) # if there is no red lantern, choose a lantern that will be red

    location = lanternLocs[redLant] # location of the red lantern
    location1 = (location[0]-10, location[1]) # adjusted location slightly for first text
    location2 = (location[0]+170, location[1]+60) # adjusted location slightly for second text
    t1 = type1[person]
    t2 = type2[case]
    print(t1)
    print(t2)

    font = pg.font.Font(None, 40)
    text1 = font.render(t1, True, (10, 10, 10))
    screen.blit(text1, text1.get_rect(centerx = location1[0], y = location1[1]))
    text2 = font.render(t2, True, (10, 10, 10))
    screen.blit(text2, text2.get_rect(centerx = location2[0], y = location2[1]))

def tipUpdate():
        global t1
        global t2
        font = pg.font.Font(None, 40)
        text1 = font.render(t1, True, (10, 10, 10))
        screen.blit(text1, text1.get_rect(centerx = location1[0], y = location1[1]))
        text2 = font.render(t2, True, (10, 10, 10))
        screen.blit(text2, text2.get_rect(centerx = location2[0], y = location2[1]))


while running:
    # pygame.QUIT event means the user clicked X to close your window
    for event in pg.event.get():
        if event.type == pg.QUIT:
            gameData["earnedPoints"] = score
            GameDataLink.send_data(gameData)
            running = False
        if current_dialogue < len(dialogue) - 3:
            if event.type == pg.MOUSEBUTTONDOWN:
                current_dialogue += 1
        elif current_dialogue >= len(dialogue) - 2:
            if event.type == pg.MOUSEBUTTONDOWN:
                current_dialogue = 0
        else:
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_RETURN:
                    print(dothraki[person][case])
                    if solution == dothraki[person][case]:
                        current_dialogue = len(dialogue) - 2
                        enemyHealth -= 1
                        lanternStatus[redLant] = False
                        solution = "I think it is..."
                        attackNotDecided = True
                        redLant = 10
                        if enemyHealth == 0:
                            initEnemy = True
                            enemy = random.randint(1,4)
                            score += 1
                        t1 = ""
                        t2 = ""
                    else:
                        current_dialogue = len(dialogue) - 1
                        playerHealth -= 1
                        # once the player is out of health, the game quits
                        if playerHealth == 0:
                            gameData["earnedPoints"] = score
                            gameData["rewardText"] = "You've run out of life!"
                            GameDataLink.send_data(gameData)
                            running = False
                        solution = "I think it is..."
                        attackNotDecided = True
                        redLant = 10
                        t1 = ""
                        t2 = ""
                elif event.key == pg.K_BACKSPACE:
                    solution = "I think it is..." if (len(solution) == 1 or solution == "I think it is...") else solution[:-1]
                elif event.__dict__["unicode"]:
                    if len(solution) < 20:
                        solution = ("" if solution == "I think it is..." else solution) + event.__dict__["unicode"]
                dialogue[len(dialogue) - 3] = solution

    # RENDER YOUR GAME HERE

    screen.blit(bgImage, (0, 0))
    enemyLoad()
    screen.blit(mainUI, (0, 0))
    ui()
    if current_dialogue == 3:
        if attackNotDecided:
            enemyAttack()
            attackNotDecided = False
    if current_dialogue >= len(dialogue) - 4:
        tipUpdate()

    pg.display.update()

    clock.tick(60)  # limits FPS to 60

pg.quit()
